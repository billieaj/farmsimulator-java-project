/**
 * @author willmiller
 * some compost to help the plants along 
 * subclass of PlantProduct
 */

public class Compost extends PlantProduct{
	
	/**
	 * constructs the compost with specific values 
	 */
	public Compost() {
		name = "Compost";
		purchasePrice = 6;
		growingDaysReduced = 3;
	}

}
