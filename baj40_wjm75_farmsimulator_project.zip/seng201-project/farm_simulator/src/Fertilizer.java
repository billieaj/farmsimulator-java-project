/**
 * @author willmiller
 * fertilizer helps plants grow 
 * a subclass of plant product
 */

public class Fertilizer extends PlantProduct{
	
	
	/**
	 *  constructs the fertilizer with specific values
	 */
	public Fertilizer() {
		name = "Fertilizer";
		purchasePrice = 5;
		growingDaysReduced = 2;
	}

}
