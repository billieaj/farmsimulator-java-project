/**
 * @author willmiller
 * a pig to roll in some mud
 * a subclass of animal
 */

public class Pig extends Animal{

	
	/** 
	 * constructs the pig with specific values 
	 */
	public Pig() {
		happiness = 30;
		health = 30;
		name = "Pig";
		purchasePrice = 60;
	}
	
	/**
	 * allows the pig to be built in GameEnvironment
	 * @param tempHappiness an input to be turned into happiness
	 * @param tempHealth  an input to be turned into health
	 * @param tempName  an input to be turned into name
	 * @param tempPurchasePrice  an input to be turned into purchasePrice
	 */
	public Pig(double tempHappiness, double tempHealth, String tempName, int tempPurchasePrice) { 
		happiness = tempHappiness;
		health = tempHealth;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
