/**
 * @author willmiller
 * a potato
 * a subclass of crop
 */

public class Potato extends Crop {

	/** 
	 * constructs the potato with specific values 
	 */
	public Potato() {
		name = "Potato";
		timeUntilHarvest = 8;
		sellingPrice = 30;
		purchasePrice = 8;
	}
	
	/**
	 * allows the potato to be built in the GameEnvironment 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Potato(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
