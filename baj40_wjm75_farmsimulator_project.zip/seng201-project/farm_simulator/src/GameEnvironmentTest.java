import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class GameEnvironmentTest {
	
	private GameEnvironment testGameEnvironment = new GameEnvironment();

	@Test
	void testCheckIntInput() {
		// no test for null input as in the GameEnvironment code, the string is an empty string if there is no input
		String invalidInt1 = "!";
		String invalidInt2 = "";
		String invalidInt3 = "a";
		String invalidInt4 = "1a";
		String invalidInt5 = "1!";
		assertFalse(testGameEnvironment.checkIntInput(invalidInt1));
		assertFalse(testGameEnvironment.checkIntInput(invalidInt2));
		assertFalse(testGameEnvironment.checkIntInput(invalidInt3));
		assertFalse(testGameEnvironment.checkIntInput(invalidInt4));
		assertFalse(testGameEnvironment.checkIntInput(invalidInt5));
		
		String validInt1 = "1";
		String validInt2 = "100";
		assertTrue(testGameEnvironment.checkIntInput(validInt1));
		assertTrue(testGameEnvironment.checkIntInput(validInt2));
	}

	@Test
	void testCheckStringInput() {
		// no test for null input as the string is an empty string if there is no input
		String invalidString1 = "!";
		String invalidString2 = "1";
		String invalidString3 = "abc1";
		String invalidString4 = "abc!";
		String invalidString5 = "123!";
		String invalidString6 = "123!a";
		String invalidString7 = "";
		assertFalse(testGameEnvironment.checkStringInput(invalidString1));
		assertFalse(testGameEnvironment.checkStringInput(invalidString2));
		assertFalse(testGameEnvironment.checkStringInput(invalidString3));
		assertFalse(testGameEnvironment.checkStringInput(invalidString4));
		assertFalse(testGameEnvironment.checkStringInput(invalidString5));
		assertFalse(testGameEnvironment.checkStringInput(invalidString6));
		assertFalse(testGameEnvironment.checkStringInput(invalidString7));
		
		String validString1 = "Abc";
		String validString2 = "a";
		String validString3 = "Bob Bobberton"; // edit function to include spaces in the regular expression
		assertTrue(testGameEnvironment.checkStringInput(validString1));
		assertTrue(testGameEnvironment.checkStringInput(validString2));
		assertTrue(testGameEnvironment.checkStringInput(validString3));
	}

	@Test
	void testCheckValidDuration() {
		int invalidDuration1 = 1;
		int invalidDuration2 = 11;
		assertFalse(testGameEnvironment.checkValidDuration(invalidDuration1));
		assertFalse(testGameEnvironment.checkValidDuration(invalidDuration2));
		
		int validDuration1 = 5;
		int validDuration2 = 7;
		int validDuration3 = 10;
		assertTrue(testGameEnvironment.checkValidDuration(validDuration1));
		assertTrue(testGameEnvironment.checkValidDuration(validDuration2));
		assertTrue(testGameEnvironment.checkValidDuration(validDuration3));
	}

	@Test
	void testCheckValidName() {
		String invalidName1 = "a";
		String invalidName2 = "!";
		String invalidName3 = "FifteenCharacters";
		String invalidName4 = "1";
		String invalidName5 = "abc!";
		String invalidName6 = "abc1";
		assertFalse(testGameEnvironment.checkValidName(invalidName1));
		assertFalse(testGameEnvironment.checkValidName(invalidName2));
		assertFalse(testGameEnvironment.checkValidName(invalidName3));
		assertFalse(testGameEnvironment.checkValidName(invalidName4));
		assertFalse(testGameEnvironment.checkValidName(invalidName5));
		assertFalse(testGameEnvironment.checkValidName(invalidName6));
		
		String validName1 = "Abc";
		String validName2 = "LessThanFifteen";
		assertTrue(testGameEnvironment.checkValidName(validName1));
		assertTrue(testGameEnvironment.checkValidName(validName2));	
	}

}
