import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FarmerTest {
	
	private Farmer testFarmer;

	@BeforeEach
	void setUp() throws Exception {
		testFarmer = new Farmer();
	}

	@Test
	void testFarmer() {
		assertEquals("Farmer", testFarmer.name);
		assertEquals(20, testFarmer.age);
		assertEquals(10, testFarmer.actionsLeft);
	}

	@Test
	void testSetName() {
		testFarmer.setName("Bob");
		assertEquals("Bob", testFarmer.name);
	}

	@Test
	void testSetAge() {
		testFarmer.setAge(100);
		assertEquals(100, testFarmer.age);
	}

	@Test
	void testRemoveAction() {
		testFarmer.removeAction();
		assertEquals(9, testFarmer.actionsLeft);
	}

	@Test
	void testResetActions() {
		testFarmer.removeAction();
		testFarmer.resetActions();
		assertEquals(10, testFarmer.actionsLeft);
	}

}
