import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FarmTest {
	
	private Farm testFarm;

	@BeforeEach
	void setUp() throws Exception {
		testFarm = new Farm();
	}

	@Test
	void testFarm() {
		assertEquals("Farm", testFarm.name);
		
		assertEquals(400, testFarm.getBalance());
		assertEquals(100, testFarm.getMaintenance());
		
		assertEquals(1, testFarm.cropGrowthMultiplier);
		assertEquals(1, testFarm.animalHealthMultiplier);
		assertEquals(1, testFarm.animalHappinessMultiplier);
		
		assertTrue(testFarm.getCropList().isEmpty());
		assertTrue(testFarm.getAnimalList().isEmpty());
		assertTrue(testFarm.getPlantProductList().isEmpty());
		assertTrue(testFarm.getAnimalProductList().isEmpty());
	}

	@Test
	void testSetName() {
		testFarm.setName("SunnyFarm");
		assertEquals("SunnyFarm", testFarm.name);
	}

	@Test
	void testGetBalance() {
		assertEquals(400, testFarm.getBalance());
	}

	@Test
	void testSetBalance() {
		testFarm.setBalance(1000);
		assertEquals(1000, testFarm.getBalance());
	}

	@Test
	void testAddBalance() {
		testFarm.addBalance(100);
		assertEquals(500, testFarm.getBalance());
	}

	@Test
	void testRemoveBalance() {
		testFarm.removeBalance(200);
		assertEquals(200, testFarm.getBalance());
	}

	@Test
	void testGetMaintenance() {
		assertEquals(100, testFarm.getMaintenance());
	}

	@Test
	void testDecreaseMaintenance() {
		testFarm.decreaseMaintenance();
		assertEquals(90, testFarm.getMaintenance());
	}

	@Test
	void testIncreaseMaintenance() {
		testFarm.increaseMaintenance();
		assertEquals(110, testFarm.getMaintenance());
	}

	@Test
	void testChooseFarmType() {
		
		testFarm.chooseFarmType(FarmTypes.NORMAL);
		assertEquals(400, testFarm.getBalance());
		assertEquals(1, testFarm.cropGrowthMultiplier);
		assertEquals(1, testFarm.animalHealthMultiplier);
		assertEquals(1, testFarm.animalHappinessMultiplier);
		
		testFarm.chooseFarmType(FarmTypes.DRY);
		assertEquals(750, testFarm.getBalance());
		assertEquals(0.5, testFarm.cropGrowthMultiplier);
		assertEquals(0.8, testFarm.animalHealthMultiplier);
		assertEquals(0.8, testFarm.animalHappinessMultiplier);
		
		testFarm.chooseFarmType(FarmTypes.FERTILE);
		assertEquals(200, testFarm.getBalance());
		assertEquals(2, testFarm.cropGrowthMultiplier);
		assertEquals(1, testFarm.animalHealthMultiplier);
		assertEquals(1, testFarm.animalHappinessMultiplier);
		
		testFarm.chooseFarmType(FarmTypes.PARADISE);
		assertEquals(200, testFarm.getBalance());
		assertEquals(1, testFarm.cropGrowthMultiplier);
		assertEquals(1.5, testFarm.animalHealthMultiplier);
		assertEquals(1.5, testFarm.animalHappinessMultiplier);
	}

	@Test
	void testGetCropList() {
		ArrayList<Crop> expected = new ArrayList<Crop>();
		assertEquals(expected, testFarm.getCropList());
	}

	@Test
	void testAddToCropList() {
		Crop carrot = new Carrot();
		testFarm.addToCropList(carrot);
		ArrayList<Crop> expected = new ArrayList<Crop>();
		expected.add(carrot);
		assertEquals(expected, testFarm.getCropList());
	}

	@Test
	void testGetAnimalList() {
		ArrayList<Animal> expected = new ArrayList<Animal>();
		assertEquals(expected, testFarm.getAnimalList());
	}

	@Test
	void testAddToAnimalList() {
		Animal sheep = new Sheep();
		testFarm.addToAnimalList(sheep);
		ArrayList<Animal> expected = new ArrayList<Animal>();
		expected.add(sheep);
		assertEquals(expected, testFarm.getAnimalList());
	}

	@Test
	void testGetPlantProductList() {
		ArrayList<PlantProduct> expected = new ArrayList<PlantProduct>();
		assertEquals(expected, testFarm.getPlantProductList());
	}

	@Test
	void testAddToPlantProductList() {
		PlantProduct fertilizer = new Fertilizer();
		testFarm.addToPlantProductList(fertilizer);
		ArrayList<PlantProduct> expected = new ArrayList<PlantProduct>();
		expected.add(fertilizer);
		assertEquals(expected, testFarm.getPlantProductList());
	}

	@Test
	void testGetAnimalProductList() {
		ArrayList<AnimalProduct> expected = new ArrayList<AnimalProduct>();
		assertEquals(expected, testFarm.getAnimalProductList());
	}

	@Test
	void testAddToAnimalProductList() {
		AnimalProduct medicine = new Medicine();
		testFarm.addToAnimalProductList(medicine);
		ArrayList<AnimalProduct> expected = new ArrayList<AnimalProduct>();
		expected.add(medicine);
		assertEquals(expected, testFarm.getAnimalProductList());
	}

}
