/**
 * @author willmiller
 * an animal to live on the farm
 * subclass of item
 *
 */

public class Animal extends Item{

	
	/**
	 * how happy the animal is 
	 * along with health, determines how much money the animal will return
	 */
	public double happiness;
	
	/**
	 * how healthy the animal is 
	 *  along with happiness, determines how much money the animal will return
	 */
	public double health;

	/** 
	 * constructs the animal with values to be added in the construction function
	 * this is how the subclasses will be constructed
	 */
	public Animal() { 
	}
	
	/**
	 * allows the animal to be created with specified values
	 * @param tempHappiness an input to be turned into happiness
	 * @param tempHealth  an input to be turned into health
	 * @param tempName  an input to be turned into name
	 * @param tempPurchasePrice  an input to be turned into purchasePrice
	 */
	public Animal(double tempHappiness, double tempHealth, String tempName, int tempPurchasePrice) { 
		happiness = tempHappiness;
		health = tempHealth;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
	/**
	 * @return a string representation of the animal
	 */
	public String toString() {
		String result = this.name + " costs: $" + this.purchasePrice + "\nwith health: " + this.health + "\nand happiness: " + this.happiness;
		return result;
	}
	/**
	 * 
	 * @param happiness how happy the animal is 
	 * @param health how healthy the animal is 
	 * @return some money to be added to the farm's balance
	 */
	public double dailyMoney(double happiness, double health) { 
		double result = 2 * happiness + 3 * health;
		return result;
	}
	
	/**
	 * @param item an AnimalProduct given by the farmer to boost the animals health
	 */
	public void gainsHealth(AnimalProduct item) {
		double healthGained = item.healthGiven;
		this.health += healthGained;
	}
	
	/**
	 * feeding the animal gives it a small boost of both happiness and health
	 */
	public void getsFed() {
		this.health += 2;
		this.happiness += 1;
	}
	
	
	/** 
	 * playing with the animal makes it happy
	 */
	public void getsPlayedWith() {
		this.happiness += 3;
	}
	
	
}


