/**
 * @author willmiller
 * a sheep to frolick on the farm
 * a specific subclass of Animal
 */

public class Sheep extends Animal{

	/**
	 * constucts the values for the sheep
	 */
	public Sheep() {
		happiness = 40;
		health = 20;
		name = "Sheep";
		purchasePrice = 75;
	}
	
	/** 
	 * allows the sheep to be built in GameEnvironment
	 * @param tempHappiness an input to be turned into happiness
	 * @param tempHealth  an input to be turned into health
	 * @param tempName  an input to be turned into name
	 * @param tempPurchasePrice  an input to be turned into purchasePrice
	 */
	public Sheep(double tempHappiness, double tempHealth, String tempName, int tempPurchasePrice) { 
		happiness = tempHappiness;
		health = tempHealth;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}


