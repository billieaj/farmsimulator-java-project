/**
 * @author willmiller
 * some barley, nice with some lemon in cordial
 * a subclass of crop 
 */

public class Barley extends Crop {

	
	/**
	 * constructs the barley with specific values
	 */
	public Barley() {
		name = "Barley";
		timeUntilHarvest = 7;
		sellingPrice = 50;
		purchasePrice = 20;
	}
	
	/**
	 * allows the barley to be built in the GameEnvironment 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Barley(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
