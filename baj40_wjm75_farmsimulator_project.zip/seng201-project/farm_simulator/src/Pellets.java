/**
 * @author willmiller
 * some pellets to keep the animals well fed and healthy
 * subclass of AnimalProduct 
 */

public class Pellets extends AnimalProduct{

	
	/**
	 * constructs the pellets with specific values
	 */
	public Pellets() { 
		name = "Packet of pellets";
		healthGiven = 20;
		purchasePrice = 10;
	}
	
}
