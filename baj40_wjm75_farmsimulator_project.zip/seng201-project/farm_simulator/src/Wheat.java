/**
 * @author willmiller
 * some wheat to grow in the fields 
 * a subclass of crop
 */

public class Wheat extends Crop {

	
	/**
	 * constructs the wheat with specific values
	 */
	public Wheat() {
		name = "Wheat";
		timeUntilHarvest = 5;
		sellingPrice = 40;
		purchasePrice = 15;
	}
	
	/**
	 * allows the wheat to be built in the GameEnvironment 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Wheat(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
