/**
 * @author willmiller
 * a cow to roam around the fields 
 * a subclass of animal
 */

public class Cow extends Animal{

	
	/**
	 * constructs the values for the cow
	 */
	public Cow() {
		happiness = 20;
		health = 40;
		name = "Cow";
		purchasePrice = 100;
	}
	
	/**
	 * allows the cow to be built in GameEnvironment
	 * @param tempHappiness an input to be turned into happiness
	 * @param tempHealth  an input to be turned into health
	 * @param tempName  an input to be turned into name
	 * @param tempPurchasePrice  an input to be turned into purchasePrice
	 */
	
	public Cow(double tempHappiness, double tempHealth, String tempName, int tempPurchasePrice) { 
		happiness = tempHappiness;
		health = tempHealth;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
}
