/**
 * @author willmiller
 * nutrients help get healthy soil going
 * a subclass of PlantProduct
 */

public class Nutrients extends PlantProduct{
	
	
	/** 
	 * constructs the nutrients with specific values 
	 */
	public Nutrients() {
		name = "Nutrients";
		purchasePrice = 7;
		growingDaysReduced = 4;
	}

}
