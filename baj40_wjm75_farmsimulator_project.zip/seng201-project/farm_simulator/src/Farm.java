import java.util.ArrayList;

/**
 * The different types of farm, used to determine the starting values.
 */
enum FarmTypes{
	NORMAL, DRY, FERTILE, PARADISE
}

/**
 * Represents a farm in the game.
 * @author Billie Johnson
 */
public class Farm {
	
	/**
	 * The name of this farm.
	 */
	public String name;
	// ArrayLists
	/**
	 * The list of crops on this farm.
	 */
	public ArrayList<Crop> cropList = new ArrayList<Crop>();
	/**
	 * The list of animals on this farm.
	 */
	public ArrayList<Animal> animalList = new ArrayList<Animal>();
	/**
	 * The list of animal products this farm has.
	 */
	public ArrayList<AnimalProduct> animalProductList = new ArrayList<AnimalProduct>();
	/**
	 * The list of plant products this farm has.
	 */
	public ArrayList<PlantProduct> plantProductList = new ArrayList<PlantProduct>();
	// Integers
	/**
	 * The current balance of this farm.
	 */
	private int balance;
	/**
	 * The maintenance level of this farm.
	 */
	private int maintenanceLevel = 100;
	// Doubles
	/**
	 * Multiplier which can increase or decrease how long it takes a crop to grow.
	 */
	public double cropGrowthMultiplier; // Multiplier for how long crops take to grow
	/**
	 * Multiplier which can increase or decrease the health of an animal.
	 */
	public double animalHealthMultiplier; // Multiplier for an animals health
	/**
	 * Multiplier which can increase or decrease the happiness of an animal.
	 */
	public double animalHappinessMultiplier; // Multiplier for an animals happiness

	/**
	 * Creates a new Farm with default values.
	 */	
	public Farm() {
		name = "Farm";
		cropGrowthMultiplier = 1;
		animalHealthMultiplier = 1;
		animalHappinessMultiplier = 1;
		balance = 400;
	}
	
	/**
	 * Changes the name of this farm.
	 * @param newName This Farm's new name.
	 */
	public void setName(String newName) {
		name = newName;
	}
	
	/**
	 * Gets the balance of this farm.
	 * @return this Farm's balance
	 */
	public int getBalance() {
		return balance;
	}
	
	/**
	 * Changes the balance of this farm.
	 * @param amount The new balance of this Farm.
	 */
	public void setBalance(int amount) {
		balance = amount;
	}
	
	/**
	 * Adds to the current balance.
	 * @param amount The amount to add to the balance.
	 */
	public void addBalance(double amount) {
		balance += amount;
	}
	
	/**
	 * Subtracts from the current balance.
	 * @param amount The amount to remove from the balance.
	 */
	public void removeBalance(int amount) {
		balance -= amount;
	}
	
	/**
	 * Gets the maintenance level of this farm.
	 * @return the maintenance level of this Farm.
	 */
	public int getMaintenance() {
		return maintenanceLevel;
	}
	
	/**
	 * Decreases the maintenance level of this farm by 10.
	 */
	public void decreaseMaintenance() {
		maintenanceLevel -= 10;
	}
	
	/**
	 * Increases the maintenance level of this farm by 10.
	 */
	public void increaseMaintenance() { 
		maintenanceLevel += 10;
	}
	
	/**
	 * Sets the cropGrowthMultiplier, animalHappinessMultiplier,
	 * animalHealthMultiplier, and balance to different values
	 * depending on the selected type.
	 * @param type The type of farm selected.
	 *				It comes from the enum FarmTypes.
	 */
	public void chooseFarmType(FarmTypes type) {
		switch(type) {
		case NORMAL: // if the selected type is normal
			cropGrowthMultiplier = 1; // normal crop growth rate
			animalHappinessMultiplier = 1; // normal animal happiness
			animalHealthMultiplier = 1; // normal animal health
			setBalance(400); // normal starting balance
			break;
		case DRY: // if the selected type is dry
			cropGrowthMultiplier = 0.5; // longer growing time
			animalHappinessMultiplier = 0.8; // decreased animal happiness
			animalHealthMultiplier = 0.8; // decreased animal health
			setBalance(750); // increased starting balance
			break;
		case FERTILE: // if the selected type is fertile
			cropGrowthMultiplier = 2; // shorter growing time
			animalHappinessMultiplier = 1; // normal animal happiness
			animalHealthMultiplier = 1; // normal animal health
			setBalance(200); // decreased starting balance
			break;
		case PARADISE: // if the selected type is paradise
			cropGrowthMultiplier = 1; // normal crop growth rate
			animalHappinessMultiplier = 1.5; // increased animal happiness
			animalHealthMultiplier = 1.5; // increased animal happiness
			setBalance(200); // decreased starting balance
			break;
		}
	}
	
	/**
	 * Gets the list of crops this farm has.
	 * @return this Farm's list of crops
	 */
	public ArrayList<Crop> getCropList(){
		return cropList;
	}
	
	/**
	 * Adds a crop to the list of crops this farm has.
	 * @param crop The Crop to add to the list of crops.
	 */
	public void addToCropList(Crop crop) {
		cropList.add(crop);
	}
	
	/**
	 * Gets the list of animals this farm has.
	 * @return this Farm's list of animals
	 */
	public ArrayList<Animal> getAnimalList(){
		return animalList;
	}
	
	/**
	 * Adds an animal to the list of animals this farm has.
	 * @param animal The Animal to add to the list of animals.
	 */
	public void addToAnimalList(Animal animal) {
		animalList.add(animal);
	}
	
	/**
	 * Gets the list of plant products this farm has.
	 * @return this Farm's list of plant products.
	 */
	public ArrayList<PlantProduct> getPlantProductList(){
		return plantProductList;
	}
	
	/**
	 * Adds a plant product to the list of plant products this farm has.
	 * @param plantProduct The PlantProduct to add to the list of plant products.
	 */
	public void addToPlantProductList(PlantProduct plantProduct) {
		plantProductList.add(plantProduct);
	}
	
	/**
	 * Gets the list of animal products this farm has.
	 * @return this Farm's list of animal products.
	 */
	public ArrayList<AnimalProduct> getAnimalProductList(){
		return animalProductList;
	}
	
	/**
	 * Adds an animal product to the list of animal products this farm has.
	 * @param animalProduct The AnimalProduct to add to the list of animal products.
	 */
	public void addToAnimalProductList(AnimalProduct animalProduct) {
		animalProductList.add(animalProduct);
	}
}