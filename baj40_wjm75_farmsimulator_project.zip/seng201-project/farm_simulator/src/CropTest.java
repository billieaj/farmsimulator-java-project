import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CropTest {
	
	private static Crop soybean;
	private static Crop carrot;
	private static PlantProduct mulch;
	private static double cropGrowthMultiplier = 2;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		soybean = new Crop(1, 3, 10, "Soybean", 5);
		carrot = new Crop(0, 0, 10, "Carrot", 1);
		mulch = new PlantProduct(5, "Mulch", 20);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		soybean.timeUntilHarvest = 3;
	}

	@Test
	void testCrop() {
		assertEquals(1, soybean.timeGrowing);
		assertEquals(3, soybean.timeUntilHarvest);
		assertEquals(10, soybean.sellingPrice);
		assertEquals("Soybean", soybean.name);
		assertEquals("Soybean", soybean.getName());
		assertEquals(5, soybean.purchasePrice);
		assertEquals(5, soybean.getPurchasePrice());
	}
	
	@Test
	void testGrowingDaysReduced() {
		soybean.growingDaysReduced(mulch);
		int expectedTimeUntilHarvest = -2;
		assertEquals(expectedTimeUntilHarvest, soybean.timeUntilHarvest);
	}
	
	@Test
	void testToString() {
		String soybeanString = soybean.toString();
		String expectedString = "Soybean costs $5, has 3\ndays until fully grown, \nand sells for $10";
		assertEquals(expectedString, soybeanString);
	}
	
	@Test
	void testDayPasses() {
		soybean.dayPasses(cropGrowthMultiplier);
		assertEquals(2, soybean.timeGrowing);
		assertEquals(1, soybean.timeUntilHarvest);
	}
	
	@Test
	void testWatered() {
		soybean.watered();
		assertEquals(2, soybean.timeUntilHarvest);
	}
	
	@Test
	void testHarvest() {
		int soybeanMoney = soybean.harvest();
		int expectedSoybeanMoney = 0;
		int carrotMoney = carrot.harvest();
		int expectedCarrotMoney = 10;
		
		assertEquals(expectedSoybeanMoney, soybeanMoney);
		assertEquals(expectedCarrotMoney, carrotMoney);
	}

}
