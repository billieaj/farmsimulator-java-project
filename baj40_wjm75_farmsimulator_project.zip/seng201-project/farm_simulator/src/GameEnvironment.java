import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

/**
 * The game environment, contains all of the UI.
 * Also contains functions to communicate with other classes.
 * @author Billie Johnson
 * @author Will Miller
 */
public class GameEnvironment {
	
	/**
	 * The total duration of the game.
	 */
	private int duration;
	/**
	 * The days remaining until the game ends.
	 */
	private int daysRemaining;
	/**
	 * The score, calculated at the end of the game.
	 */
	private int score;
	/**
	 * The farm object.
	 */
	private Farm farm = new Farm();
	/**
	 * The farmer object.
	 */
	private Farmer farmer = new Farmer();
	/**
	 * Used to determine which stage of the setup the user is at.
	 */
	public int stage = 1;
	/**
	 * Used to keep track of the currently selected choice.
	 */
	public String selected;
	/**
	 * The list of items available in the store for the player to purchase
	 */
	public ArrayList<Item> storeItemList = new ArrayList<Item>();   
	
	/**
	 *  A basket for the player to fill up while shopping in the store
	 */
	public ArrayList<Item> storeBasket = new ArrayList<Item>();		
	
	
		// Items
		Barley barley = new Barley();
		Carrot carrot = new Carrot();
		Kumara kumara = new Kumara();
		Parsnip parsnip = new Parsnip();
		Potato potato = new Potato();
		Wheat wheat = new Wheat();
		
		Cow cow = new Cow(20*farm.animalHappinessMultiplier, 40*farm.animalHealthMultiplier, "Cow", 100);
		Pig pig = new Pig(30*farm.animalHappinessMultiplier, 30*farm.animalHealthMultiplier, "Pig", 60);
		Sheep sheep = new Sheep(40*farm.animalHappinessMultiplier, 20*farm.animalHealthMultiplier, "Sheep", 75);
		
		Compost compost = new Compost();
		Fertilizer fertilizer = new Fertilizer();
		Nutrients nutrients = new Nutrients();
		WeedKiller weedKiller = new WeedKiller();
		
		Medicine medicine = new Medicine();
		Pellets pellets = new Pellets();

	
	JFrame window;
	JPanel titleNamePanel, startButtonPanel, setupTextPanel, nextButtonPanel, textFieldPanel, invalidTextPanel, farmTypesPanel, farmStatsPanel, statusPanel, mainButtonPanel, maintenancePanel, cropPanel, animalPanel, actionPanel, itemStatusPanel, itemPanel, itemStatsPanel, noActionsPanel, backButtonPanel, storePanel, headerPanel, storeCropPanel, storeAnimalPanel, storeCropProductPanel, storeAnimalProductPanel, infoPanel, scorePanel, buttonPanel, basketItemsPanel,purchasePanel;
	JLabel titleNameLabel, invalidLabel, daysLabel, actionsLabel, balanceLabel, maintenanceLabel, noActionsLabel, welcomeLabel, animalLabel, cropLabel, animalProductLabel, plantProductLabel, infoLabel, productinfoLabel, finalScoreLabel, scoreLabel, basketWelcomeLabel;
	JButton startButton, nextButton, normalFarmButton, dryFarmButton, fertileFarmButton, paradiseFarmButton, farmButton, viewStoreButton, viewCropsButton, viewAnimalsButton, tendFarmButton, nextDayButton, choice1, choice2, choice3, choice4, choice5, choice6, water, item1, item2, item3, item4, backButton, action1, action2, basketButton, barleyButton, wheatButton, carrotButton, kumaraButton, parsnipButton, potatoButton, pigButton, cowButton, sheepButton, weedKillerButton, nutrientsButton, fertilizerButton, compostButton, pelletsButton, medicineButton, restartButton, exitButton, backToStoreButton, purchaseButton, viewBasketButton;
	JTextArea setupTextArea, normalFarmStats, dryFarmStats, fertileFarmStats, paradiseFarmStats, itemStatus, waterStats, item1Stats, item2Stats, item3Stats, item4Stats, productInfoArea, basketTextArea;
	JTextField textField;
	
	// Fonts
	Font titleFont = new Font("Arial", Font.PLAIN, 120);
	Font startFont = new Font("Arial", Font.PLAIN, 50);
	Font generalFont = new Font("Arial", Font.PLAIN, 30);
	Font smallerGeneralFont = new Font("Arial", Font.PLAIN, 20);
	
	// Event handlers
	TitleScreenHandler titleScreenHandler = new TitleScreenHandler();
	SetupScreenHandler setupScreenHandler = new SetupScreenHandler();
	FarmSelectionHandler farmSelectionHandler = new FarmSelectionHandler();
	MainScreenHandler mainScreenHandler = new MainScreenHandler();
	CropScreenHandler cropScreenHandler = new CropScreenHandler();
	AnimalScreenHandler animalScreenHandler = new AnimalScreenHandler();
	StoreScreenHandler storeScreenHandler = new StoreScreenHandler();
	EndScreenHandler endScreenHandler = new EndScreenHandler();
	BasketHandler basketHandler = new BasketHandler();
	BasketScreenHandler basketScreenHandler = new BasketScreenHandler();
	
	/**
	 * Starts the game.
	 * @param args
	 */
	public static void main(String[] args) {
		new GameEnvironment();
	}

	/**
	 * Creates the game window, and launches the start screen.
	 */
	public GameEnvironment() {
		// creates the window
		window = new JFrame("Farm Simulator");
		window.setSize(1200, 800); // sets the window size
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // sets what happens when the window is closed
		window.getContentPane().setBackground(Color.darkGray); // sets the background colour of the window
		window.setLayout(null); // sets the layout of the window
		
		// creates the start screen
		createStartScreen();

		// makes the window visible
		window.setVisible(true);
	}
	
	/**
	 * Creates the starting screen of the game, the title screen.
	 * Creates UI for the window, the title text, and the start button.
	 */
	public void createStartScreen() {
		// creates panel to display the game title
				titleNamePanel = new JPanel(); // creates the panel
				titleNamePanel.setBounds(100, 100, 1000, 150); // sets size of the panel
				titleNamePanel.setBackground(Color.gray); // sets the background colour of the panel
				// label to display the game title
				titleNameLabel = new JLabel("Farm Simulator"); // creates the label
				titleNameLabel.setForeground(Color.white); // sets the text colour of the label
				titleNameLabel.setFont(titleFont); // sets the font of the label
				titleNamePanel.add(titleNameLabel); // adds the label to the panel
				
				// creates panel to display the start button
				startButtonPanel = new JPanel();
				startButtonPanel.setBounds(400, 450, 400, 100);
				startButtonPanel.setBackground(Color.darkGray);
				// button to open the setup screen
				startButton = new JButton("START"); // creates the button
				startButton.setBackground(Color.gray); // sets the background colour of the button
				startButton.setForeground(Color.white); // sets the text colour of the button
				startButton.setFont(startFont); // sets the font of the button
				startButton.setFocusPainted(false);
				startButton.addActionListener(titleScreenHandler); // adds action to the button
				startButtonPanel.add(startButton); // adds the button to the panel
				
				// adds the panels to the window
				window.add(titleNamePanel); 
				window.add(startButtonPanel);
	}
	
	/**
	 * Resets everything from the starting screen to be invisible.
	 */
	public void closeStartScreen() {
		titleNamePanel.setVisible(false); // makes the panel invisible
		startButtonPanel.setVisible(false);
	}
	
	/**
	 * Creates the setup screen of the game.
	 * Creates UI for the instructions for each step of the setup,
	 * a text field for input, a next button to move to the next
	 * stage of the setup, and text to inform you when the input is
	 * invalid. Also creates UI for selecting different farm types, 
	 * and displaying their different benefits.
	 * Goes through different stages for choosing the duration
	 * of the game, naming your farmer, choosing the age of your
	 * farmer, choosing the type of farm to play with, and 
	 * naming your farm.
	 */
	public void createSetupScreen() {
		// resets everything from the start screen
		closeStartScreen();
		
		// creates panel to hold the text area
		setupTextPanel = new JPanel(); // creates the panel
		setupTextPanel.setBounds(100, 100, 1000, 150); // sets the size of the panel
		setupTextPanel.setBackground(Color.darkGray); // sets the background colour of the panel
		// text area to display the instructions for setup
		setupTextArea = new JTextArea("How many days would you like the game to last?\nPlease enter a number between 5 and 10."); // creates the text area
		setupTextArea.setBounds(100, 100, 1000, 150); // sets the size of the text area
		setupTextArea.setBackground(Color.darkGray); // sets the background colour of the text area
		setupTextArea.setForeground(Color.white); // sets the text colour of the text area
		setupTextArea.setFont(generalFont); // sets the font of the text area
		setupTextArea.setLineWrap(true); // enables text to continue onto a new line
		setupTextArea.setWrapStyleWord(true); // ensures words are not split in half by the line wrap
		setupTextPanel.add(setupTextArea); // adds the text area to the panel
		
		// creates panel to hold the text field
		textFieldPanel = new JPanel();
		textFieldPanel.setBounds(200, 300, 800, 50);
		textFieldPanel.setBackground(Color.darkGray);
		// text field to get text that the user inputs
		textField = new JTextField(20); // creates the text field, number is the width (number of columns)
		textField.setBackground(Color.white); // sets the background colour of the text field
		textField.setForeground(Color.black); // sets the foreground colour of the text field
		textField.setFont(generalFont); // sets the font of the text field
		textFieldPanel.add(textField); // adds the text field to the panel
		
		// creates panel to display the invalid input text
		invalidTextPanel = new JPanel();
		invalidTextPanel.setBounds(400, 350, 400, 50);
		invalidTextPanel.setBackground(Color.darkGray);
		// label to display the invalid input text
		invalidLabel = new JLabel("Invalid input"); // creates the label
		invalidLabel.setBackground(Color.gray); // sets the background colour of the label
		invalidLabel.setForeground(Color.white); // sets the text colour of the label
		invalidLabel.setFont(generalFont); // sets the font of the label
		invalidTextPanel.add(invalidLabel); // adds the label to the panel
		
		// creates panel to display buttons for the farm types
		farmTypesPanel = new JPanel();
		farmTypesPanel.setBounds(100, 250, 1000, 50);
		farmTypesPanel.setBackground(Color.gray);
		farmTypesPanel.setLayout(new GridLayout(1, 4)); // sets the layout of the panel
		// creates panel to display text areas, which display the stats of each farm type
		farmStatsPanel = new JPanel();
		farmStatsPanel.setBounds(100, 300, 1000, 100);
		farmStatsPanel.setBackground(Color.darkGray);
		farmStatsPanel.setLayout(new GridLayout(1, 4));
		// button for normal FarmType
		normalFarmButton = new JButton("Normal"); // creates the button
		normalFarmButton.setBackground(Color.gray); // sets the background colour of the button
		normalFarmButton.setForeground(Color.white); // sets the text colour of the button
		normalFarmButton.setFont(generalFont); // sets the font of the button
		normalFarmButton.setFocusPainted(false);
		normalFarmButton.addActionListener(farmSelectionHandler); // adds action to the button
		normalFarmButton.setActionCommand("normal"); // adds action command to the button, a string which can be used for a switch
		// text area for normal FarmType
		normalFarmStats = new JTextArea("Normal crop growth rate\nNormal animal health\nNormal animal happiness\nStarting balance: $400");
		normalFarmStats.setBounds(100, 100, 250, 50);
		normalFarmStats.setBackground(Color.gray);
		normalFarmStats.setForeground(Color.white);
		normalFarmStats.setFont(smallerGeneralFont);
		normalFarmStats.setLineWrap(true);
		farmTypesPanel.add(normalFarmButton); // adds the button to the panel
		farmStatsPanel.add(normalFarmStats);
		// button for dry FarmType
		dryFarmButton = new JButton("Dry");
		dryFarmButton.setBackground(Color.gray);
		dryFarmButton.setForeground(Color.white);
		dryFarmButton.setFont(generalFont);
		dryFarmButton.setFocusPainted(false);
		dryFarmButton.addActionListener(farmSelectionHandler);
		dryFarmButton.setActionCommand("dry");
		// text area for dry FarmType
		dryFarmStats = new JTextArea("Halved crop growth rate\nLower animal health\nLower animal happiness\nStarting balance: $750");
		dryFarmStats.setBounds(100, 100, 250, 50);
		dryFarmStats.setBackground(Color.gray);
		dryFarmStats.setForeground(Color.white);
		dryFarmStats.setFont(smallerGeneralFont);
		dryFarmStats.setLineWrap(true);
		farmTypesPanel.add(dryFarmButton);
		farmStatsPanel.add(dryFarmStats);
		// button for fertile FarmType
		fertileFarmButton = new JButton("Fertile");
		fertileFarmButton.setBackground(Color.gray);
		fertileFarmButton.setForeground(Color.white);
		fertileFarmButton.setFont(generalFont);
		fertileFarmButton.setFocusPainted(false);
		fertileFarmButton.addActionListener(farmSelectionHandler);
		fertileFarmButton.setActionCommand("fertile");
		// text area for fertile FarmType
		fertileFarmStats = new JTextArea("Doubled crop growth rate\nNormal animal health\nNormal animal happiness\nStarting balance: $200");
		fertileFarmStats.setBounds(100, 100, 250, 50);
		fertileFarmStats.setBackground(Color.gray);
		fertileFarmStats.setForeground(Color.white);
		fertileFarmStats.setFont(smallerGeneralFont);
		fertileFarmStats.setLineWrap(true);
		farmTypesPanel.add(fertileFarmButton);
		farmStatsPanel.add(fertileFarmStats);
		// button for paradise FarmType
		paradiseFarmButton = new JButton("Paradise");
		paradiseFarmButton.setBackground(Color.gray);
		paradiseFarmButton.setForeground(Color.white);
		paradiseFarmButton.setFont(generalFont);
		paradiseFarmButton.setFocusPainted(false);
		paradiseFarmButton.addActionListener(farmSelectionHandler);
		paradiseFarmButton.setActionCommand("paradise");
		// text area for paradise FarmType
		paradiseFarmStats = new JTextArea("Normal crop growth rate\nDoubled animal health\nDoubled animal happiness\nStarting balance: $200");
		paradiseFarmStats.setBounds(100, 100, 250, 50);
		paradiseFarmStats.setBackground(Color.gray);
		paradiseFarmStats.setForeground(Color.white);
		paradiseFarmStats.setFont(smallerGeneralFont);
		paradiseFarmStats.setLineWrap(true);
		farmTypesPanel.add(paradiseFarmButton);
		farmStatsPanel.add(paradiseFarmStats);
		
		// creates panel to display the next button
		nextButtonPanel = new JPanel();
		nextButtonPanel.setBounds(400, 450, 400, 100);
		nextButtonPanel.setBackground(Color.darkGray);
		// button to go to the next stage of setup
		nextButton = new JButton("NEXT");
		nextButton.setBackground(Color.gray);
		nextButton.setForeground(Color.white);
		nextButton.setFont(startFont);
		nextButton.setFocusPainted(false);
		nextButtonPanel.add(nextButton);
		nextButton.addActionListener(setupScreenHandler);
		
		// adds the panels to the window
		window.add(setupTextPanel);
		window.add(textFieldPanel);
		window.add(invalidTextPanel);
		window.add(farmTypesPanel);
		window.add(farmStatsPanel);
		window.add(nextButtonPanel);
		
		invalidTextPanel.setVisible(false);
		farmTypesPanel.setVisible(false);
		farmStatsPanel.setVisible(false);
	}
	
	/**
	 * Resets everything from the setup screen to be invisible.
	 */
	public void closeSetupScreen() {
		setupTextPanel.setVisible(false); // makes the panel invisible
		textFieldPanel.setVisible(false);
		farmTypesPanel.setVisible(false);
		farmStatsPanel.setVisible(false);
		nextButtonPanel.setVisible(false);
	}
	
	/**
	 * Creates the main screen of the game.
	 * 
	 */
	public void createMainScreen() {
		// resets everything from the setup screen
		closeSetupScreen();
		
		// creates panel to display game status information
		statusPanel = new JPanel(); // creates the panel
		statusPanel.setBounds(100, 15, 400, 150); // sets the size of the panel
		statusPanel.setBackground(Color.darkGray); // sets the background colour of the panel
		statusPanel.setLayout(new GridLayout(3, 1)); // sets the layout of the panel
		// label to display daysRemaining
		daysLabel = new JLabel("Days remaining: " + daysRemaining); // creates the label
		daysLabel.setForeground(Color.white); // sets the text colour of the label
		daysLabel.setFont(generalFont); // sets the font of the label
		statusPanel.add(daysLabel); // adds the label to the panel
		// label to display actionsRemaining
		actionsLabel = new JLabel("Actions remaining: " + farmer.actionsLeft);
		actionsLabel.setForeground(Color.white);
		actionsLabel.setFont(generalFont);
		statusPanel.add(actionsLabel);
		// label to display the current balance
		balanceLabel = new JLabel("Balance: $" + farm.getBalance());
		balanceLabel.setForeground(Color.white);
		balanceLabel.setFont(generalFont);
		statusPanel.add(balanceLabel);
		
		// creates panel to display buttons for possible actions
		mainButtonPanel = new JPanel();
		mainButtonPanel.setBounds(200, 300, 800, 200);
		mainButtonPanel.setBackground(Color.darkGray);
		mainButtonPanel.setLayout(new GridLayout(3, 2));
		// button to view maintenanceLevel
		farmButton = new JButton("View Farm Maintenance"); // creates the button
		farmButton.setBackground(Color.gray); // sets the background colour of the button
		farmButton.setForeground(Color.white); // sets the text colour of the button
		farmButton.setFont(generalFont); // sets the font of the button
		farmButton.setFocusPainted(false);
		farmButton.addActionListener(mainScreenHandler); // adds action to the button
		farmButton.setActionCommand("farm"); // adds action command to the button, a string that can be used for switch
		mainButtonPanel.add(farmButton); // adds the button to the panel
		// button to open storeScreen
		viewStoreButton = new JButton("View Store");
		viewStoreButton.setBackground(Color.gray);
		viewStoreButton.setForeground(Color.white);
		viewStoreButton.setFont(generalFont);
		farmButton.setFocusPainted(false);
		viewStoreButton.addActionListener(mainScreenHandler);
		viewStoreButton.setActionCommand("store");
		mainButtonPanel.add(viewStoreButton);
		// button to view a screen with the crops and appropriate actions
		viewCropsButton = new JButton("View Crops");
		viewCropsButton.setBackground(Color.gray);
		viewCropsButton.setForeground(Color.white);
		viewCropsButton.setFont(generalFont);
		viewCropsButton.setFocusPainted(false);
		viewCropsButton.addActionListener(mainScreenHandler);
		viewCropsButton.setActionCommand("crops");
		mainButtonPanel.add(viewCropsButton);
		// button to view a screen with the animals and appropriate actions
		viewAnimalsButton = new JButton("View Animals");
		viewAnimalsButton.setBackground(Color.gray);
		viewAnimalsButton.setForeground(Color.white);
		viewAnimalsButton.setFont(generalFont);
		viewAnimalsButton.setFocusPainted(false);
		viewAnimalsButton.addActionListener(mainScreenHandler);
		viewAnimalsButton.setActionCommand("animals");
		mainButtonPanel.add(viewAnimalsButton);
		// button to increase the maintenance level of the farm
		tendFarmButton = new JButton("Tend Farm");
		tendFarmButton.setBackground(Color.gray);
		tendFarmButton.setForeground(Color.white);
		tendFarmButton.setFont(generalFont);
		tendFarmButton.setFocusPainted(false);
		tendFarmButton.addActionListener(mainScreenHandler);
		tendFarmButton.setActionCommand("tend");
		mainButtonPanel.add(tendFarmButton);
		// button to proceed to the next day
		nextDayButton = new JButton("Next Day");
		nextDayButton.setBackground(Color.gray);
		nextDayButton.setForeground(Color.white);
		nextDayButton.setFont(generalFont);
		nextDayButton.setFocusPainted(false);
		nextDayButton.addActionListener(mainScreenHandler);
		nextDayButton.setActionCommand("next");
		mainButtonPanel.add(nextDayButton);
		
		// creates panel to display maintenanceLevel
		maintenancePanel = new JPanel();
		maintenancePanel.setBounds(350, 550, 500, 50);
		maintenancePanel.setBackground(Color.darkGray);
		// label to display maintenanceLevel
		maintenanceLabel = new JLabel("Maintenance level is at " + farm.getMaintenance() + "%");
		maintenanceLabel.setForeground(Color.white);
		maintenanceLabel.setFont(generalFont);
		maintenancePanel.add(maintenanceLabel);
		
		// creates panel to display a label
		noActionsPanel = new JPanel();
		noActionsPanel.setBounds(250, 600, 700, 50);
		noActionsPanel.setBackground(Color.darkGray);
		// label to indicate that there are no actions remaining
		noActionsLabel = new JLabel("No actions remaining, proceed to the next day");
		noActionsLabel.setForeground(Color.white);
		noActionsLabel.setFont(generalFont);
		noActionsPanel.add(noActionsLabel);
		
		// adds panels to the window
		window.add(statusPanel);
		window.add(mainButtonPanel);
		window.add(maintenancePanel);
		window.add(noActionsPanel);
		
		maintenancePanel.setVisible(false);
		noActionsPanel.setVisible(false);
	}
	
	/**
	 * Resets everything from the main screen to be invisible.
	 */
	public void closeMainScreen() {
		statusPanel.setVisible(false); // makes the panels invisible
		mainButtonPanel.setVisible(false);
		maintenancePanel.setVisible(false);
	}
	
	/**
	 * Creates the store screen, where the player can view and purchase items for their farm
	 * @author Will Miller
	 */
	public void createStoreScreen() {
		// resets everything from the game screen
		closeMainScreen();

		// if it isn't already loaded, load the list of items that the store offers
		if(storeItemList.isEmpty() == true) {
			setStoreItemList(storeItemList);
		}

		//a panel for the back button
		backButtonPanel = new JPanel();
		backButtonPanel.setBounds(0, 0, 70, 50);
		backButtonPanel.setBackground(Color.darkGray);
		
		// and the buttn to go on that panel
		backButton = new JButton("Back");
		backButton.setBackground(Color.gray);
		backButton.setForeground(Color.white);
		backButton.setFont(generalFont);
		backButton.setFocusPainted(false);
		backButton.addActionListener(storeScreenHandler);
		backButton.setActionCommand("back");
		backButtonPanel.add(backButton);
		
		// create a panel to display store information
		storePanel = new JPanel(); 
		storePanel.setBounds(100, 0, 900, 100); 
		storePanel.setBackground(Color.gray); 
		storePanel.setLayout(new GridLayout(1, 2)); 
		
		// label to welcome the farmer
		welcomeLabel = new JLabel("Welcome to the store!"); 
		welcomeLabel.setForeground(Color.white); 
		welcomeLabel.setFont(generalFont); 
		storePanel.add(welcomeLabel);
		
		// a button that takes the player to the basket screen when pushed
		viewBasketButton = new JButton("View Basket");
		viewBasketButton.setBackground(Color.black);
		viewBasketButton.setForeground(Color.white);
		viewBasketButton.setFont(generalFont);
		viewBasketButton.addActionListener(basketHandler);
		viewBasketButton.setActionCommand("view basket");
		storePanel.add(viewBasketButton);
		
		// a panel in the bottom right corner on which the player can view item details and add them to the basket
		infoPanel = new JPanel();
		infoPanel.setBounds(750, 500, 300, 250);
		infoPanel.setBackground(Color.gray);
		infoPanel.setLayout(new GridLayout(3, 1));
		
		// a label for the infoPanel
		infoLabel = new JLabel("Item info"); 
		infoLabel.setForeground(Color.white); 
		infoLabel.setFont(generalFont); 
		infoPanel.add(infoLabel);
		
		// an area upon which the details for different items is displayed
		// the info is displayed when the product is clicked on 
		productInfoArea = new JTextArea();
		productInfoArea.setBackground(Color.black);
		productInfoArea.setForeground(Color.white); 
		productInfoArea.setFont(smallerGeneralFont); 
		productInfoArea.setLineWrap(true);
		infoPanel.add(productInfoArea);
		
		// if a player likes the look of a certain item, this button will add it to their basket
		// the adding happens down at basketHandler, that is also where the ActionCommand is set, since it's different for each item
		basketButton = new JButton("Add to Basket");
		basketButton.setBackground(Color.black);
		basketButton.setForeground(Color.white);
		basketButton.setFont(generalFont);
		basketButton.addActionListener(basketHandler);
		infoPanel.add(basketButton);
		
		// a panel to hold the titles for the different types of items
		headerPanel = new JPanel();
		headerPanel.setBounds(100, 150, 900, 100); 
		headerPanel.setBackground(Color.gray); 
		headerPanel.setLayout(new GridLayout(1, 4)); 
		
		// says Crops. The crop items will be in the column below this label
		cropLabel = new JLabel("Crops:"); 
		cropLabel.setForeground(Color.white); 
		cropLabel.setFont(smallerGeneralFont); 
		headerPanel.add(cropLabel);
		
		// says Animals. The Animal items will be in the column below this label
		animalLabel = new JLabel("Animals:");
		animalLabel.setForeground(Color.white); 
		animalLabel.setFont(smallerGeneralFont); 
		headerPanel.add(animalLabel); 
		
		// says Plant Products. The PlantProduct items will be in the column below this label
		plantProductLabel = new JLabel("Plant Products:"); 
		plantProductLabel.setForeground(Color.white); 
		plantProductLabel.setFont(smallerGeneralFont); 
		headerPanel.add(plantProductLabel); 
		
		// says Animal Products. The AnimalProduct items will be in the column below this label
		animalProductLabel = new JLabel("Animal Products:"); 
		animalProductLabel.setForeground(Color.white); 
		animalProductLabel.setFont(smallerGeneralFont); 
		headerPanel.add(animalProductLabel); 
		
		// the next few blocks of code are mainly buttons to add the products to the farmer's basket
		
		// the column panel in which the crop buttons will sit
		storeCropPanel = new JPanel();
		storeCropPanel.setBounds(100, 300, 200, 400);
		storeCropPanel.setBackground(Color.blue);
		storeCropPanel.setLayout(new GridLayout(6, 1));
	
		// Barley
		barleyButton = new JButton("Barley");
		barleyButton.setBackground(Color.black);
		barleyButton.setForeground(Color.white);
		barleyButton.setFont(generalFont);
		barleyButton.addActionListener(storeScreenHandler);
		barleyButton.setActionCommand("barley");
		storeCropPanel.add(barleyButton);
		
		// Wheat 
		wheatButton = new JButton("Wheat");
		wheatButton.setBackground(Color.black);
		wheatButton.setForeground(Color.white);
		wheatButton.setFont(generalFont);
		wheatButton.addActionListener(storeScreenHandler);
		wheatButton.setActionCommand("wheat");
		storeCropPanel.add(wheatButton);
		
		// Carrot
		carrotButton = new JButton("Carrot");
		carrotButton.setBackground(Color.black);
		carrotButton.setForeground(Color.white);
		carrotButton.setFont(generalFont);
		carrotButton.addActionListener(storeScreenHandler);
		carrotButton.setActionCommand("carrot");
		storeCropPanel.add(carrotButton);
		
		// Kumara
		kumaraButton = new JButton("Kumara");
		kumaraButton.setBackground(Color.black);
		kumaraButton.setForeground(Color.white);
		kumaraButton.setFont(generalFont);
		kumaraButton.addActionListener(storeScreenHandler);
		kumaraButton.setActionCommand("kumara");
		storeCropPanel.add(kumaraButton);
		
		// Parsnip
		parsnipButton = new JButton("Parsnip");
		parsnipButton.setBackground(Color.black);
		parsnipButton.setForeground(Color.white);
		parsnipButton.setFont(generalFont);
		parsnipButton.addActionListener(storeScreenHandler);
		parsnipButton.setActionCommand("parsnip");
		storeCropPanel.add(parsnipButton);
		
		// Potato
		potatoButton = new JButton("Potato");
		potatoButton.setBackground(Color.black);
		potatoButton.setForeground(Color.white);
		potatoButton.setFont(generalFont);
		potatoButton.addActionListener(storeScreenHandler);
		potatoButton.setActionCommand("potato");
		storeCropPanel.add(potatoButton);
		
		// animals in the second column
		storeAnimalPanel = new JPanel();
		storeAnimalPanel.setBounds(300, 300, 200, 200);
		storeAnimalPanel.setBackground(Color.blue);
		storeAnimalPanel.setLayout(new GridLayout(3, 1));
		
		// Cow
		cowButton = new JButton("Cow");
		cowButton.setBackground(Color.black);
		cowButton.setForeground(Color.white);
		cowButton.setFont(generalFont);
		cowButton.addActionListener(storeScreenHandler);
		cowButton.setActionCommand("cow");
		storeAnimalPanel.add(cowButton);
		
		// Pig
		pigButton = new JButton("Pig");
		pigButton.setBackground(Color.black);
		pigButton.setForeground(Color.white);
		pigButton.setFont(generalFont);
		pigButton.addActionListener(storeScreenHandler);
		pigButton.setActionCommand("pig");
		storeAnimalPanel.add(pigButton);
		
		// Sheep
		sheepButton = new JButton("Sheep");
		sheepButton.setBackground(Color.black);
		sheepButton.setForeground(Color.white);
		sheepButton.setFont(generalFont);
		sheepButton.addActionListener(storeScreenHandler);
		sheepButton.setActionCommand("sheep");
		storeAnimalPanel.add(sheepButton);
		

		
		// then crop products
		storeCropProductPanel = new JPanel();
		storeCropProductPanel.setBounds(500, 300, 200, 267);
		storeCropProductPanel.setBackground(Color.blue);
		storeCropProductPanel.setLayout(new GridLayout(4, 1));
		
		// Weed Killer
		weedKillerButton = new JButton("Weed Killer");
		weedKillerButton.setBackground(Color.black);
		weedKillerButton.setForeground(Color.white);
		weedKillerButton.setFont(generalFont);
		weedKillerButton.addActionListener(storeScreenHandler);
		weedKillerButton.setActionCommand("weedKiller");
		storeCropProductPanel.add(weedKillerButton);
		
		// Nutrients
		nutrientsButton = new JButton("Nutrients");
		nutrientsButton.setBackground(Color.black);
		nutrientsButton.setForeground(Color.white);
		nutrientsButton.setFont(generalFont);
		nutrientsButton.addActionListener(storeScreenHandler);
		nutrientsButton.setActionCommand("nutrients");
		storeCropProductPanel.add(nutrientsButton);
		
		// Fertilizer
		fertilizerButton = new JButton("Fertilizer");
		fertilizerButton.setBackground(Color.black);
		fertilizerButton.setForeground(Color.white);
		fertilizerButton.setFont(generalFont);
		fertilizerButton.addActionListener(storeScreenHandler);
		fertilizerButton.setActionCommand("fertilizer");
		storeCropProductPanel.add(fertilizerButton);
		
		// Compost
		compostButton = new JButton("Compost");
		compostButton.setBackground(Color.black);
		compostButton.setForeground(Color.white);
		compostButton.setFont(generalFont);
		compostButton.addActionListener(storeScreenHandler);
		compostButton.setActionCommand("compost");
		storeCropProductPanel.add(compostButton);
		
		// and finally animal products
		storeAnimalProductPanel = new JPanel();
		storeAnimalProductPanel.setBounds(700, 300, 200, 134);
		storeAnimalProductPanel.setBackground(Color.blue);
		storeAnimalProductPanel.setLayout(new GridLayout(2, 1));
		
		// Pellets
		pelletsButton = new JButton("Pellets");
		pelletsButton.setBackground(Color.black);
		pelletsButton.setForeground(Color.white);
		pelletsButton.setFont(generalFont);
		pelletsButton.addActionListener(storeScreenHandler);
		pelletsButton.setActionCommand("pellets");
		storeAnimalProductPanel.add(pelletsButton);
		
		// Medicine
		medicineButton = new JButton("Medicine");
		medicineButton.setBackground(Color.black);
		medicineButton.setForeground(Color.white);
		medicineButton.setFont(generalFont);
		medicineButton.addActionListener(storeScreenHandler);
		medicineButton.setActionCommand("medicine");
		storeAnimalProductPanel.add(medicineButton);
		
		// adding the panels to the window
		window.add(backButtonPanel);
		window.add(storePanel);
		window.add(headerPanel);
		window.add(storeCropPanel);
		window.add(storeAnimalPanel);
		window.add(storeCropProductPanel);
		window.add(storeAnimalProductPanel);
		window.add(infoPanel);
		
	}
	
	
	/**
	 *  Resets everything from the StoreScreen to be invisible
	 */
	public void closeStoreScreen() {
		backButtonPanel.setVisible(false);
		storePanel.setVisible(false);
		headerPanel.setVisible(false);
		storeCropPanel.setVisible(false);
		storeAnimalPanel.setVisible(false);
		storeCropProductPanel.setVisible(false);
		storeAnimalProductPanel.setVisible(false);
		infoPanel.setVisible(false);
	}
	

	/**
	 * @author willmiller
	 * A screen accessed from the store screen in which the player can view the items in their basket and purchase those items if they wish
	 */
    public void createBasketScreen() {
		
    	// A back button that takes the player back to the store screen
    	backToStoreButton = new JButton("Back to store");
    	backToStoreButton.setBackground(Color.black);
    	backToStoreButton.setForeground(Color.white);
    	backToStoreButton.setFont(generalFont);
    	backToStoreButton.addActionListener(basketScreenHandler);
    	backToStoreButton.setActionCommand("back");
    	backToStoreButton.setBounds(0, 600, 300, 100);
    	
    	// The panel which has "Basket" and the purchase button on it 
		purchasePanel = new JPanel(); 
		purchasePanel.setBounds(100, 0, 900, 100); 
		purchasePanel.setBackground(Color.gray); 
		purchasePanel.setLayout(new GridLayout(1, 2)); 
		
		// A label to indicate the basket items sit below
		basketWelcomeLabel = new JLabel("Basket:"); 
		basketWelcomeLabel.setForeground(Color.white); 
		basketWelcomeLabel.setFont(generalFont); 
		purchasePanel.add(basketWelcomeLabel);
		
		// A button which allows the player to purchase the items in the basket
		// The purchasing is done down at basketHandler
		purchaseButton = new JButton("Purchase Items");
		purchaseButton.setBackground(Color.black);
		purchaseButton.setForeground(Color.white);
		purchaseButton.setFont(generalFont);
		purchaseButton.addActionListener(basketScreenHandler);
		purchaseButton.setActionCommand("purchase");
		purchasePanel.add(purchaseButton);
    	
		// A panel which will display the items in the player's basket
		basketItemsPanel = new JPanel(); 
		basketItemsPanel.setBounds(100, 100, 300, 400); 
		basketItemsPanel.setBackground(Color.gray); 
		basketItemsPanel.setLayout(new GridLayout(1, 1)); 
		
		// The text area put on the panel to display the items in the player's basket
    	basketTextArea = new JTextArea();
    	String basketItems = "";
    	for (Item item: storeBasket) { 				//iterate over the items in the basket and add it to the String basketItems
    		basketItems += item.getName() + "\n";
    	}
    	basketTextArea.setText(basketItems); 		// that string is then set as the text for the TextArea
    	basketTextArea.setLineWrap(true);
    	basketTextArea.setBackground(Color.black);
    	basketTextArea.setFont(generalFont);
    	basketTextArea.setForeground(Color.white);
		basketItemsPanel.add(basketTextArea);
		
    	
		// add the panels & button to the window
    	window.add(backToStoreButton);
    	window.add(purchasePanel);
    	window.add(basketItemsPanel);
    	
    }
    
    /**
     * Resets everything from the BasketScreen to be invisible
     */
    public void closeBasketScreen() {
    	backToStoreButton.setVisible(false);
    	purchasePanel.setVisible(false);
    	basketItemsPanel.setVisible(false);
    }

	
	
	
	/**
	 * Creates the crop screen of the game, which 
	 * has a back button to return to the main screen, 
	 * buttons for the different crops the farm has, 
	 * buttons for harvesting crops or tending to a  
	 * selected crop, and buttons for which plant 
	 * product the player would like to use to tend 
	 * to the selected crop.
	 */ 
	public void createCropScreen() {
		
		// resets everything from the game screen
		closeMainScreen();
		
		// creates panel to display the back button
		backButtonPanel = new JPanel(); // creates the panel
		backButtonPanel.setBounds(80, 180, 150, 50); // sets the size of the panel
		backButtonPanel.setBackground(Color.darkGray); // sets the background colour of the panel
		// button to go back to the main screen
		backButton = new JButton("Back"); // creates the button
		backButton.setBackground(Color.gray); // sets the background colour of the button
		backButton.setForeground(Color.white); // sets the font colour of the button
		backButton.setFont(generalFont); // sets the font of the button
		backButton.setFocusPainted(false);
		backButton.addActionListener(cropScreenHandler); // adds action to the button
		backButton.setActionCommand("back"); // adds action command to the button, a String which can be used for switch
		backButtonPanel.add(backButton); // adds the button to the panel
		
		// creates panel to hold the Crop buttons
		cropPanel = new JPanel();
		cropPanel.setBounds(300, 200, 300, 300);
		cropPanel.setBackground(Color.gray);
		cropPanel.setLayout(new GridLayout(6, 1)); // sets the layout of the panel
		// button for the first crop in the farm's crop list
		choice1 = new JButton();
		choice1.setBackground(Color.gray);
		choice1.setForeground(Color.white);
		choice1.setFont(generalFont);
		choice1.setFocusPainted(false);
		choice1.addActionListener(cropScreenHandler);
		choice1.setActionCommand("1");
		cropPanel.add(choice1);
		if(farm.cropList.size() >= 1) { // checks that the first index exists
			choice1.setText(farm.cropList.get(0).name); // sets the text of the button to the crop name
		}
		// button for the second crop in the farm's crop list
		choice2 = new JButton();
		choice2.setBackground(Color.gray);
		choice2.setForeground(Color.white);
		choice2.setFont(generalFont);
		choice2.setFocusPainted(false);
		choice2.addActionListener(cropScreenHandler);
		choice2.setActionCommand("2");
		cropPanel.add(choice2);
		if(farm.cropList.size() >= 2) {
			choice2.setText(farm.cropList.get(1).name);
		}
		// button for the third crop in the farm's crop list
		choice3 = new JButton();
		choice3.setBackground(Color.gray);
		choice3.setForeground(Color.white);
		choice3.setFont(generalFont);
		choice3.setFocusPainted(false);
		choice3.addActionListener(cropScreenHandler);
		choice3.setActionCommand("3");
		cropPanel.add(choice3);
		if(farm.cropList.size() >= 3) {
			choice3.setText(farm.cropList.get(2).name);
		}
		// button for the fourth crop in the farm's crop list
		choice4 = new JButton();
		choice4.setBackground(Color.gray);
		choice4.setForeground(Color.white);
		choice4.setFont(generalFont);
		choice4.setFocusPainted(false);
		choice4.addActionListener(cropScreenHandler);
		choice4.setActionCommand("4");
		cropPanel.add(choice4);
		if(farm.cropList.size() >= 4) {
			choice4.setText(farm.cropList.get(3).name);
		}
		// button for the fifth crop in the farm's crop list
		choice5 = new JButton();
		choice5.setBackground(Color.gray);
		choice5.setForeground(Color.white);
		choice5.setFont(generalFont);
		choice5.setFocusPainted(false);
		choice5.addActionListener(cropScreenHandler);
		choice5.setActionCommand("5");
		cropPanel.add(choice5);
		if(farm.cropList.size() >= 5) {
			choice5.setText(farm.cropList.get(4).name);
		}
		// button for the sixth crop in the farm's crop list
		choice6 = new JButton();
		choice6.setBackground(Color.gray);
		choice6.setForeground(Color.white);
		choice6.setFont(generalFont);
		choice6.setFocusPainted(false);
		choice6.addActionListener(cropScreenHandler);
		choice6.setActionCommand("6");
		cropPanel.add(choice6);
		if(farm.cropList.size() >= 6) {
			choice6.setText(farm.cropList.get(5).name);
		}
		
		// creates panel to hold the action buttons
		actionPanel = new JPanel();
		actionPanel.setBounds(700, 200, 320, 120);
		actionPanel.setBackground(Color.darkGray);
		actionPanel.setLayout(new GridLayout(2, 1));
		// button for harvesting crops
		action1 = new JButton();
		action1.setText("Harvest Crops");
		action1.setBackground(Color.gray);
		action1.setForeground(Color.white);
		action1.setFont(generalFont);
		action1.setFocusPainted(false);
		action1.addActionListener(cropScreenHandler);
		action1.setActionCommand("harvest");
		actionPanel.add(action1);
		// button for tending to the selected crop
		action2 = new JButton();
		action2.setText("Tend Crop");
		action2.setBackground(Color.gray);
		action2.setForeground(Color.white);
		action2.setFont(generalFont);
		action2.setFocusPainted(false);
		action2.addActionListener(cropScreenHandler);
		action2.setActionCommand("tend");
		actionPanel.add(action2);
		
		// creates panel for displaying the crop's status
		itemStatusPanel = new JPanel();
		itemStatusPanel.setBounds(700, 380, 320, 120);
		itemStatusPanel.setBackground(Color.gray);
		// text area for displaying the crop's status
		itemStatus = new JTextArea(""); // creates the text area
		itemStatus.setBounds(710, 390, 300, 100); // sets the size of the text area
		itemStatus.setBackground(Color.gray); // sets the background colour of the text area
		itemStatus.setForeground(Color.white); // sets the font colour of the text area
		itemStatus.setFont(smallerGeneralFont); // sets the font of the text area
		itemStatus.setLineWrap(true); // enables the text to continue onto the next line
		itemStatus.setWrapStyleWord(true); // ensures that words are not split in half by the line wrap
		itemStatusPanel.add(itemStatus); // adds the text area to the panel
		
		// creates panel for displaying the plant product items
		itemPanel = new JPanel();
		itemPanel.setBounds(225, 550, 850, 50);
		itemPanel.setBackground(Color.gray);
		itemPanel.setLayout(new GridLayout(1, 5));
		// creates panel for displaying the attributes of the plant product items
		itemStatsPanel = new JPanel();
		itemStatsPanel.setBounds(225, 600, 850, 100);
		itemStatsPanel.setBackground(Color.gray);
		itemStatsPanel.setLayout(new GridLayout(1, 5));
		
		// button for watering the selected crop
		water = new JButton("Water");
		water.setBackground(Color.gray);
		water.setForeground(Color.white);
		water.setFont(generalFont);
		water.setFocusPainted(false);
		water.addActionListener(cropScreenHandler);
		water.setActionCommand("water");
		itemPanel.add(water);
		// text area for the attributes of water
		waterStats = new JTextArea("Reduces the growing time of a crop by 1 day");
		waterStats.setBackground(Color.gray);
		waterStats.setForeground(Color.white);
		waterStats.setFont(smallerGeneralFont);
		waterStats.setLineWrap(true);
		waterStats.setWrapStyleWord(true);
		itemStatsPanel.add(waterStats);
		
		// button for the first item in the plant product list
		item1 = new JButton("");
		item1.setBackground(Color.gray);
		item1.setForeground(Color.white);
		item1.setFont(generalFont);
		item1.setFocusPainted(false);
		item1.addActionListener(cropScreenHandler);
		item1.setActionCommand("item1");
		itemPanel.add(item1);
		// text area for the attributes of the first item in the plant product list
		item1Stats = new JTextArea("");
		item1Stats.setBackground(Color.gray);
		item1Stats.setForeground(Color.white);
		item1Stats.setFont(smallerGeneralFont);
		item1Stats.setLineWrap(true);
		item1Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item1Stats);
		if(farm.plantProductList.size() >= 1) { // checks that item exists at the index
			item1.setText(farm.plantProductList.get(0).name);
			item1Stats.setText("Reduces the growing time of a crop by " + farm.plantProductList.get(0).growingDaysReduced + " days");
		}
		// button for the second item in the plant product list
		item2 = new JButton("");
		item2.setBackground(Color.gray);
		item2.setForeground(Color.white);
		item2.setFont(generalFont);
		item2.setFocusPainted(false);
		item2.addActionListener(cropScreenHandler);
		item2.setActionCommand("item2");
		itemPanel.add(item2);
		// text area for the attributes of the second item in the plant product list
		item2Stats = new JTextArea("");
		item2Stats.setBackground(Color.gray);
		item2Stats.setForeground(Color.white);
		item2Stats.setFont(smallerGeneralFont);
		item2Stats.setLineWrap(true);
		item2Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item2Stats);
		if(farm.plantProductList.size() >= 2) { // checks that item exists at the index
			item2.setText(farm.plantProductList.get(1).name);
			item2Stats.setText("Reduces the growing time of a crop by " + farm.plantProductList.get(1).growingDaysReduced + " days");
		}
		// button for the third item in the plant product list
		item3 = new JButton("");
		item3.setBackground(Color.gray);
		item3.setForeground(Color.white);
		item3.setFont(generalFont);
		item3.setFocusPainted(false);
		item3.addActionListener(cropScreenHandler);
		item3.setActionCommand("item3");
		itemPanel.add(item3);
		// text area for the attributes of the third item in the plant product list
		item3Stats = new JTextArea("");
		item3Stats.setBackground(Color.gray);
		item3Stats.setForeground(Color.white);
		item3Stats.setFont(smallerGeneralFont);
		item3Stats.setLineWrap(true);
		item3Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item3Stats);
		if(farm.plantProductList.size() >= 3) { // checks that item exists at the index
			item3.setText(farm.plantProductList.get(2).name);
			item3Stats.setText("Reduces the growing time of a crop by " + farm.plantProductList.get(2).growingDaysReduced + " days");
		}
		// button for the fourth item in the plant product list
		item4 = new JButton("");
		item4.setBackground(Color.gray);
		item4.setForeground(Color.white);
		item4.setFont(generalFont);
		item4.setFocusPainted(false);
		item4.addActionListener(cropScreenHandler);
		item4.setActionCommand("");
		itemPanel.add(item4);
		// text area for the attributes of the fourth item in the plant product list
		item4Stats = new JTextArea("");
		item4Stats.setBackground(Color.gray);
		item4Stats.setForeground(Color.white);
		item4Stats.setFont(smallerGeneralFont);
		item4Stats.setLineWrap(true);
		item4Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item4Stats);
		if(farm.plantProductList.size() >= 4) { // checks that item exists at the index
			item4.setText(farm.plantProductList.get(3).name);
			item4Stats.setText("Reduces the growing time of a crop by " + farm.plantProductList.get(3).growingDaysReduced + " days");
		}
		
		// adds the panels to the window
		window.add(backButtonPanel);
		window.add(cropPanel);
		window.add(actionPanel);
		window.add(itemStatusPanel);
		window.add(itemPanel);
		window.add(itemStatsPanel);
		
		itemPanel.setVisible(false); // makes the panels invisible
		itemStatsPanel.setVisible(false);
		
		statusPanel.setVisible(true); // makes the status panel visible
	}
	
	/**
	 * Resets everything from the crop screen to be invisible.
	 */
	public void closeCropScreen() {
		backButtonPanel.setVisible(false); // makes the panels invisible
		statusPanel.setVisible(false);
		cropPanel.setVisible(false);
		actionPanel.setVisible(false);
		itemStatusPanel.setVisible(false);
		itemPanel.setVisible(false);
		itemStatsPanel.setVisible(false);
		selected = null; // resets the selected choice
	}
	
	/**
	 * Creates the animal screen of the game, which 
	 * has a back button to return to the main screen, 
	 * buttons for the different animals the farm has, 
	 * buttons for playing with or feeding a selected 
	 * animal, and buttons for animal products that 
	 * the player can use on the selected animal.
	 */ 
	public void createAnimalScreen() {
		
		// resets everything from the game screen
		closeMainScreen();
		
		// creates panel to display the back button
		backButtonPanel = new JPanel(); // creates the panel
		backButtonPanel.setBounds(80, 180, 150, 50); // sets the size of the panel
		backButtonPanel.setBackground(Color.darkGray); // sets the background colour of the panel
		// button to go back to the main screen
		backButton = new JButton("Back"); // creates the button
		backButton.setBackground(Color.gray); // sets the background colour of the button
		backButton.setForeground(Color.white); // sets the font colour of the button
		backButton.setFont(generalFont); // sets the font of the button
		backButton.setFocusPainted(false);
		backButton.addActionListener(animalScreenHandler); // adds action to the button
		backButton.setActionCommand("back"); // adds action listener to the button, a String which can be used for switch
		backButtonPanel.add(backButton); // adds the button to the panel
		
		// creates panel to hold the animal buttons
		animalPanel = new JPanel();
		animalPanel.setBounds(300, 200, 300, 200);
		animalPanel.setBackground(Color.gray);
		animalPanel.setLayout(new GridLayout(4, 1)); // sets the layout of the panel
		// button for the first animal in the farm's animal list
		choice1 = new JButton();
		choice1.setBackground(Color.gray);
		choice1.setForeground(Color.white);
		choice1.setFont(generalFont);
		choice1.setFocusPainted(false);
		choice1.addActionListener(animalScreenHandler);
		choice1.setActionCommand("1");
		animalPanel.add(choice1);
		if(farm.animalList.size() >= 1) {
			choice1.setText(farm.animalList.get(0).name);
		}
		// button for the second animal in the farm's animal list
		choice2 = new JButton();
		choice2.setBackground(Color.gray);
		choice2.setForeground(Color.white);
		choice2.setFont(generalFont);
		choice2.setFocusPainted(false);
		choice2.addActionListener(animalScreenHandler);
		choice2.setActionCommand("2");
		animalPanel.add(choice2);
		if(farm.animalList.size() >= 2) {
			choice2.setText(farm.animalList.get(1).name);
		}
		// button for the third animal in the farm's animal list
		choice3 = new JButton();
		choice3.setBackground(Color.gray);
		choice3.setForeground(Color.white);
		choice3.setFont(generalFont);
		choice3.setFocusPainted(false);
		choice3.addActionListener(animalScreenHandler);
		choice3.setActionCommand("3");
		animalPanel.add(choice3);
		if(farm.animalList.size() >= 3) {
			choice3.setText(farm.animalList.get(2).name);
		}
		// button for the fourth animal in the farm's animal list
		choice4 = new JButton();
		choice4.setBackground(Color.gray);
		choice4.setForeground(Color.white);
		choice4.setFont(generalFont);
		choice4.setFocusPainted(false);
		choice4.addActionListener(animalScreenHandler);
		choice4.setActionCommand("4");
		animalPanel.add(choice4);
		if(farm.animalList.size() >= 4) {
			choice4.setText(farm.animalList.get(3).name);
		}
		
		// creates panel to hold the action buttons
		actionPanel = new JPanel();
		actionPanel.setBounds(700, 200, 320, 120);
		actionPanel.setBackground(Color.darkGray);
		actionPanel.setLayout(new GridLayout(2, 1));
		// button for playing with the selected animal
		action1 = new JButton();
		action1.setText("Play With Animal");
		action1.setBackground(Color.gray);
		action1.setForeground(Color.white);
		action1.setFont(generalFont);
		action1.setFocusPainted(false);
		action1.addActionListener(animalScreenHandler);
		action1.setActionCommand("play");
		actionPanel.add(action1);
		// button for feeding the selected animal
		action2 = new JButton();
		action2.setText("Feed Animal");
		action2.setBackground(Color.gray);
		action2.setForeground(Color.white);
		action2.setFont(generalFont);
		action2.setFocusPainted(false);
		action2.addActionListener(animalScreenHandler);
		action2.setActionCommand("feed");
		actionPanel.add(action2);
		
		// creates panel for displaying the animal's status
		itemStatusPanel = new JPanel();
		itemStatusPanel.setBounds(700, 380, 320, 120);
		itemStatusPanel.setBackground(Color.gray);
		// text area for displaying the animal's status
		itemStatus = new JTextArea(""); // creates the text area
		itemStatus.setBounds(710, 390, 300, 100); // sets the size of the text area
		itemStatus.setBackground(Color.gray); // sets the background colour of the text area
		itemStatus.setForeground(Color.white); // sets the text colour of the text area
		itemStatus.setFont(smallerGeneralFont); // sets the font of the text area
		itemStatus.setLineWrap(true); // enables the text to continue onto the next line
		itemStatus.setWrapStyleWord(true); // ensures that words aren't split between lines
		itemStatusPanel.add(itemStatus); // adds the text area to the panel
		
		// creates panel for displaying the animal product items
		itemPanel = new JPanel();
		itemPanel.setBounds(225, 550, 850, 50);
		itemPanel.setBackground(Color.gray);
		itemPanel.setLayout(new GridLayout(1, 4));
		// creates panel for displaying the attributes of the animal product items
		itemStatsPanel = new JPanel();
		itemStatsPanel.setBounds(225, 600, 850, 100);
		itemStatsPanel.setBackground(Color.gray);
		itemStatsPanel.setLayout(new GridLayout(1, 4));
		// button for the first item in the animal product list
		item1 = new JButton("");
		item1.setBackground(Color.gray);
		item1.setForeground(Color.white);
		item1.setFont(generalFont);
		item1.setFocusPainted(false);
		item1.addActionListener(animalScreenHandler);
		item1.setActionCommand("item1");
		itemPanel.add(item1);
		// text area for the attributes of the first item in the animal product list
		item1Stats = new JTextArea("");
		item1Stats.setBackground(Color.gray);
		item1Stats.setForeground(Color.white);
		item1Stats.setFont(smallerGeneralFont);
		item1Stats.setLineWrap(true);
		item1Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item1Stats);
		if(farm.animalProductList.size() >= 1) { // checks that item exists at the index
			item1.setText(farm.animalProductList.get(0).name);
			item1Stats.setText("Increases the health of an animal by " + farm.animalProductList.get(0).healthGiven);
		}
		// button for the second item in the animal product list
		item2 = new JButton("");
		item2.setBackground(Color.gray);
		item2.setForeground(Color.white);
		item2.setFont(generalFont);
		item2.setFocusPainted(false);
		item2.addActionListener(animalScreenHandler);
		item2.setActionCommand("item2");
		itemPanel.add(item2);
		// text area for the attributes of the second item in the animal product list
		item2Stats = new JTextArea("");
		item2Stats.setBackground(Color.gray);
		item2Stats.setForeground(Color.white);
		item2Stats.setFont(smallerGeneralFont);
		item2Stats.setLineWrap(true);
		item2Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item2Stats);
		if(farm.animalProductList.size() >= 2) { // checks that item exists at the index
			item2.setText(farm.animalProductList.get(1).name);
			item2Stats.setText("Increases the health of an animal by " + farm.animalProductList.get(1).healthGiven);
		}
		// button for the third item in the animal product list
		item3 = new JButton("");
		item3.setBackground(Color.gray);
		item3.setForeground(Color.white);
		item3.setFont(generalFont);
		item3.setFocusPainted(false);
		item3.addActionListener(animalScreenHandler);
		item3.setActionCommand("item3");
		itemPanel.add(item3);
		// text area for the attributes of the third item in the animal product list
		item3Stats = new JTextArea("");
		item3Stats.setBackground(Color.gray);
		item3Stats.setForeground(Color.white);
		item3Stats.setFont(smallerGeneralFont);
		item3Stats.setLineWrap(true);
		item3Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item3Stats);
		if(farm.animalProductList.size() >= 3) { // checks that item exists at the index
			item3.setText(farm.animalProductList.get(2).name);
			item3Stats.setText("Increases the health of an animal by " + farm.animalProductList.get(2).healthGiven);
		}
		// button for the fourth item in the animal product list
		item4 = new JButton("");
		item4.setBackground(Color.gray);
		item4.setForeground(Color.white);
		item4.setFont(generalFont);
		item4.setFocusPainted(false);
		item4.addActionListener(animalScreenHandler);
		item4.setActionCommand("");
		itemPanel.add(item4);
		// text area for the attributes of the fourth item in the animal product list
		item4Stats = new JTextArea("");
		item4Stats.setBackground(Color.gray);
		item4Stats.setForeground(Color.white);
		item4Stats.setFont(smallerGeneralFont);
		item4Stats.setLineWrap(true);
		item4Stats.setWrapStyleWord(true);
		itemStatsPanel.add(item4Stats);
		if(farm.animalProductList.size() >= 4) { // checks that item exists at the index
			item4.setText(farm.animalProductList.get(3).name);
			item4Stats.setText("Increases the health of an animal by " + farm.animalProductList.get(3).healthGiven);
		}
		
		// adds the panels to the window
		window.add(backButtonPanel);
		window.add(animalPanel);
		window.add(actionPanel);
		window.add(itemStatusPanel);
		window.add(itemPanel);
		window.add(itemStatsPanel);
		
		statusPanel.setVisible(true); // makes the status panel visible
	}
	
	/**
	 * Resets everything from the animal screen to be invisible.
	 */
	public void closeAnimalScreen()
	{
		backButtonPanel.setVisible(false); // makes the panels invisible
		statusPanel.setVisible(false);
		animalPanel.setVisible(false);
		actionPanel.setVisible(false);
		itemStatusPanel.setVisible(false);
		itemPanel.setVisible(false);
		itemStatsPanel.setVisible(false);
		selected = null; // resets the selected choice
	}
	
	/**
	 * Creates the end screen of the game, which 
	 * displays the final score and has buttons 
	 * that allow the player to restart the game 
	 * or exit the game.
	 */ 
	public void createEndScreen() {
		// resets everything from the main screen
		closeMainScreen();
		
		// creates panel to display the final score
		scorePanel = new JPanel(); // creates the panel
		scorePanel.setBounds(100, 200, 1000, 200); // sets size of the panel
		scorePanel.setBackground(Color.darkGray); // sets the background colour of the panel
		scorePanel.setLayout(new GridLayout(2, 1)); // sets the layout of the panel
		// label to display "Final Score"
		finalScoreLabel = new JLabel("Final Score", SwingConstants.CENTER); // creates the label
		finalScoreLabel.setForeground(Color.white); // sets the text colour of the label
		finalScoreLabel.setFont(titleFont); // sets the font of the label
		scorePanel.add(finalScoreLabel); // adds the label to the panel
		// label to display the score
		scoreLabel = new JLabel("" + score, SwingConstants.CENTER);
		scoreLabel.setForeground(Color.white);
		scoreLabel.setFont(titleFont);
		scorePanel.add(scoreLabel);
		
		// creates panel to display buttons
		buttonPanel = new JPanel();
		buttonPanel.setBounds(400, 500, 400, 75);
		buttonPanel.setBackground(Color.gray);
		buttonPanel.setLayout(new GridLayout(1, 2));
		// button to restart game
		restartButton = new JButton("Restart"); // creates the button
		restartButton.setBackground(Color.gray); // sets the background colour of the button
		restartButton.setForeground(Color.white); // sets the text colour of the button
		restartButton.setFont(generalFont); // sets the font of the button
		restartButton.addActionListener(endScreenHandler); // adds action to the button
		restartButton.setActionCommand("restart"); // adds action command to the button, a String which can be used for switch
		buttonPanel.add(restartButton); // adds the button to the panel
		// button to exit game
		exitButton = new JButton("Exit");
		exitButton.setBackground(Color.gray);
		exitButton.setForeground(Color.white);
		exitButton.setFont(generalFont);
		exitButton.addActionListener(endScreenHandler);
		exitButton.setActionCommand("exit");
		buttonPanel.add(exitButton);
		
		// adds the panels to the window
		window.add(scorePanel);
		window.add(buttonPanel);
	}
	
	/**
	 * Resets everything from the end screen to be invisible.
	 */
	public void closeEndScreen() {
		scorePanel.setVisible(false); // makes the panels invisible
		buttonPanel.setVisible(false);
	}
	
	/**
	 * Handles pressing the start button on the start screen.
	 * @author Billie Johnson
	 */
	public class TitleScreenHandler implements ActionListener{
		/**
		 * When the button on the start screen is pressed, 
		 * the setup screen is opened.
		 */
		public void actionPerformed(ActionEvent event) {
			createSetupScreen(); // creates the setup screen
		}
	}
	
	/**
	 * Handles pressing the next button to move to the
	 * next stage of the setup. Does different things 
	 * depending on the stage.
	 * @author Billie Johnson
	 */
	public class SetupScreenHandler implements ActionListener{
		/**
		 * Implements a switch based on the stage of 
		 * the setup.
		 * If it's on the first stage, then the text 
		 * that the user has input into the text field 
		 * is gotten and checked to see if it's a valid 
		 * integer and a valid duration. If it isn't, 
		 * the user is prompted to enter a valid 
		 * duration. If the input is valid, then the 
		 * setDuration() function is called, the text 
		 * field is reset, the instructions are updated 
		 * for the next stage, and the stage is increased 
		 * by 1.
		 * If it's on the second stage, then the text that
		 * the user has input into the text field is gotten 
		 * and checked to see if it's a valid name. If it isn't, 
		 * the user is prompted to enter a valid name. If the 
		 * input is valid, farmer.setName() is called, the 
		 * text field is reset, the instructions are updated 
		 * for the next stage, and the stage is increased by 1.
		 * If it's on the third stage, then the text that the
		 * user has input into the text field is gotten and 
		 * checked to see if it's a valid integer. If it isn't, 
		 * the user is prompted to enter a valid age. If the 
		 * input is valid, farmer.setAge() is called, the 
		 * text field is reset, the instructions are updated 
		 * for the next stage, the buttons and information 
		 * for each farm type are displayed on screen, the 
		 * text field is hidden, and the stage is increased 
		 * by 1.
		 * If it's on the fourth stage, the instructions 
		 * are updated for the next stage, the buttons and 
		 * information for each farm type are hidden, the 
		 * text field is displayed on screen, and the stage 
		 * is increased by 1.
		 * If it's on the fifth stage, then the text that the 
		 * user has input into the text field is gotten and 
		 * checked to see if it's a valid name. If it isn't, 
		 * the user is prompted to enter a valid name. If the 
		 * input is valid, farm.setName() is called, the text 
		 * field is reset, and the main screen is opened.
		 * @param event
		 */
		public void actionPerformed(ActionEvent event) {
			switch(stage) {
			case 1:
				String inputDuration = "0";
				do {
					do {
						inputDuration = textField.getText();
						invalidTextPanel.setVisible(true);
						textField.setText("");
					}
					while(checkIntInput(inputDuration) != true);
					invalidTextPanel.setVisible(true);
				}
				while(checkValidDuration(Integer.parseInt(inputDuration)) != true);
				invalidTextPanel.setVisible(false);
				setDuration(Integer.parseInt(inputDuration));
				textField.setText("");
				setupTextArea.setText("What would you like to name your farmer?\nThe name must be between 3 and 15 characters, with no special characters or numbers.");
				stage += 1;
				break;
			case 2:
				String inputName = "";
				inputName = textField.getText();
				if(checkValidName(inputName) == true) {
					farmer.setName(inputName);
					textField.setText("");
					invalidTextPanel.setVisible(false);
					setupTextArea.setText("How old would you like your farmer to be?");
					stage += 1;
				}
				else {
					invalidTextPanel.setVisible(true);
					textField.setText("");
				}
				break;
			case 3:
				String inputAge = "";
				do {
					invalidTextPanel.setVisible(true);
					inputAge = textField.getText();
					textField.setText("");
					if(checkIntInput(inputAge) != true){
						invalidTextPanel.setVisible(true);
					}
				}
				while(checkIntInput(inputAge) != true);
				farmer.setAge(Integer.parseInt(inputAge));
				textField.setText("");
				invalidTextPanel.setVisible(false);
				textFieldPanel.setVisible(false);
				farmTypesPanel.setVisible(true);
				farmStatsPanel.setVisible(true);
				setupTextArea.setText("What kind of farm would you like?");
				stage += 1;
				break;
			case 4:
				setupTextArea.setText("What would you like to name your farm?");
				farmTypesPanel.setVisible(false);
				farmStatsPanel.setVisible(false);
				textFieldPanel.setVisible(true);
				stage += 1;
				break;
			case 5:
				inputName = "";
				inputName = textField.getText();
				if(checkValidName(inputName) == true) {
					invalidTextPanel.setVisible(false);
					farm.setName(inputName);
					textField.setText("");
					createMainScreen();
				}
				else {
					invalidTextPanel.setVisible(true);
					textField.setText("");
				}
				break;
			}
		}
	}
	
	/**
	 * Handles the farm selection, sets the 
	 * attributes of the farm based on which 
	 * farm type button the player has clicked.
	 * @author Billie Johnson
	 */
	public class FarmSelectionHandler implements ActionListener{
		/**
		 * Implements a switch based on the action command
		 * output by the button that the user clicks.
		 * Sets the attributes of the farm differently 
		 * depending on which farm type the player has 
		 * selected.
		 * Changes the colour of the button that is selected, 
		 * to indicate that it has been selected.
		 * @param event
		 */
		public void actionPerformed(ActionEvent event) {
			String farmType = event.getActionCommand(); // the string linked to the button you have pressed
			switch(farmType) {
			// what happens if the normal button is pressed
			case "normal":
				farm.chooseFarmType(FarmTypes.NORMAL); // sets the attributes of the farm based on the type selected
				normalFarmButton.setBackground(Color.lightGray); // highlights the selected button
				dryFarmButton.setBackground(Color.gray); // resets the colours of the other buttons
				fertileFarmButton.setBackground(Color.gray);
				paradiseFarmButton.setBackground(Color.gray);
				break;
			// what happens if the dry button is pressed
			case "dry":
				farm.chooseFarmType(FarmTypes.DRY);
				dryFarmButton.setBackground(Color.lightGray);
				normalFarmButton.setBackground(Color.gray);
				fertileFarmButton.setBackground(Color.gray);
				paradiseFarmButton.setBackground(Color.gray);
				break;
			// what happens if the fertile button is pressed
			case "fertile":
				farm.chooseFarmType(FarmTypes.FERTILE);
				fertileFarmButton.setBackground(Color.lightGray);
				normalFarmButton.setBackground(Color.gray);
				dryFarmButton.setBackground(Color.gray);
				paradiseFarmButton.setBackground(Color.gray);
				break;
			// what happens if the paradise button is pressed
			case "paradise":
				farm.chooseFarmType(FarmTypes.PARADISE);
				paradiseFarmButton.setBackground(Color.lightGray);
				normalFarmButton.setBackground(Color.gray);
				dryFarmButton.setBackground(Color.gray);
				fertileFarmButton.setBackground(Color.gray);
				break;
			}
		}
	}
	
	/**
	 * Handles any actions taking place on the main screen,
	 * such as viewing the maintenance level of the farm, 
	 * opening the store screen, opening the crop screen,
	 * opening the animal screen, tending to the farm, and
	 * moving to the next day.
	 * @author Billie Johnson
	 */
	public class MainScreenHandler implements ActionListener{
		/**
		 * Implements a switch based on the action command
		 * output by the button that the user clicks.
		 * If the user clicks on the view farm maintenance 
		 * button, then the viewStatus() function is called 
		 * with the farm, which shows the maintenance level.
		 * If the user clicks on the view store button,
		 * then the store screen is opened by calling the 
		 * createStoreScreen() function.
		 * If the user clicks on the view crops button then 
		 * the crop screen is opened by calling the 
		 * createCropScreen() function.
		 * If the user clicks on the view animals button then 
		 * the animal screen is opened by calling the 
		 * createAnimalScreen() function.
		 * If the user clicks on the tend farm button then 
		 * the tendLand() function is called, which increases 
		 * the maintenance level of the farm.
		 * If the user clicks on the next day button then 
		 * the nextDay() function is called.
		 * @param event
		 */
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // the string linked to the button you have pressed
			switch(choice) {
			// what happens if the view farm maintenance button is pressed
			case "farm":
				viewStatus(farm); // shows the maintenance level of the farm
				break;
			// what happens if the view store button is pressed
			case "store":
				createStoreScreen(); // opens the store screen
				break;
			// what happens if the view crops button is pressed
			case "crops":
				createCropScreen(); // opens the crop screen
				break;
			// what happens if the view animals button is pressed
			case "animals":
				createAnimalScreen(); // opens the animal screen
				break;
			// what happens if the tend farm button is pressed
			case "tend":
				tendLand(); // increases the maintenance level of the farm
				break;
			// what happens if the next day button is pressed
			case "next":
				nextDay();
				break;
			}
		}
	}
	
	/**
	 * Handles any actions taking place on the crop screen,
	 * such as selecting a crop from the list (of buttons),
	 * harvesting crops, tending to a selected crop, choosing
	 * choosing which item you use to tend to the crop, and 
	 * pressing the back button.
	 * @author Billie Johnson
	 */
	public class CropScreenHandler implements ActionListener{
		/**
		 * Implements a switch based on the action command
		 * output by the button that the user clicks.
		 * If the user clicks any of the buttons representing
		 * crops, the crop is selected and the crop's status
		 * is shown on screen.
		 * If the user clicks on the harvest crops button,
		 * then the harvestCrops() function is called.
		 * If the user clicks on the tend crop button, the 
		 * plant product items that the farm has are shown
		 * on screen, and the user can select which one they
		 * want to use on the crop, which then calls the
		 * tendCrop() function with the selected crop and the 
		 * plant product they want to use if they selected one.
		 * If the user clicks on the back button, then the crop
		 * screen is closed and the main screen is opened.
		 * @param event
		 */
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
			// what happens if you press the first button in the list
			case "1":
				if(farm.getCropList().size() >= 1) { // checks to make sure there is a crop at the first index (zero-indexed)
					viewStatus(farm.getCropList().get(0)); // calls the viewStatus function with the first crop in cropList
					selected = "1"; // updates which choice is currently selected
					choice1.setBackground(Color.lightGray); // highlights the selected text
					choice2.setBackground(Color.gray); // resets all other texts to their standard colour
					choice3.setBackground(Color.gray);
					choice4.setBackground(Color.gray);
					choice5.setBackground(Color.gray);
					choice6.setBackground(Color.gray);
				}
				break;
			case "2":
				if(farm.getCropList().size() >= 2) {
					viewStatus(farm.getCropList().get(1));
					selected = "2";
					choice2.setBackground(Color.lightGray);
					choice1.setBackground(Color.gray);
					choice3.setBackground(Color.gray);
					choice4.setBackground(Color.gray);
					choice5.setBackground(Color.gray);
					choice6.setBackground(Color.gray);
				}
				break;
			case "3":
				if(farm.getCropList().size() >= 3) {
					viewStatus(farm.getCropList().get(2));
					selected = "3";
					choice3.setBackground(Color.lightGray);
					choice1.setBackground(Color.gray);
					choice2.setBackground(Color.gray);
					choice4.setBackground(Color.gray);
					choice5.setBackground(Color.gray);
					choice6.setBackground(Color.gray);
				}
				break;
			case "4":
				if(farm.getCropList().size() >= 4) {
					viewStatus(farm.getCropList().get(3));
					selected = "4";
					choice4.setBackground(Color.lightGray);
					choice1.setBackground(Color.gray);
					choice2.setBackground(Color.gray);
					choice3.setBackground(Color.gray);
					choice5.setBackground(Color.gray);
					choice6.setBackground(Color.gray);
				}
				break;
			case "5":
				if(farm.getCropList().size() >= 5) {
					viewStatus(farm.getCropList().get(4));
					selected = "5";
					choice5.setBackground(Color.lightGray);
					choice1.setBackground(Color.gray);
					choice2.setBackground(Color.gray);
					choice3.setBackground(Color.gray);
					choice4.setBackground(Color.gray);
					choice6.setBackground(Color.gray);
				}
				break;
			case "6":
				if(farm.getCropList().size() >= 6) {
					viewStatus(farm.getCropList().get(5));
					selected = "6";
					choice6.setBackground(Color.lightGray);
					choice1.setBackground(Color.gray);
					choice2.setBackground(Color.gray);
					choice3.setBackground(Color.gray);
					choice4.setBackground(Color.gray);
					choice5.setBackground(Color.gray);
				}
				break;
			// what happens if you press the Harvest Crops button
			case "harvest":
				harvestCrops(); // calls the harvestCrops function
				break;
			// what happens if you press the Tend Crop button
			case "tend":
				if(selected != null) { // checks to ensure the player has selected a crop
					itemPanel.setVisible(true); // makes the plant product items visible
					itemStatsPanel.setVisible(true);
				}
				break;
			// what happens if you press the first plant product button
			case "item1":
				if(selected != null) { // checks to ensure the player has selected a crop
					int selectedIndex = Integer.parseInt(selected) - 1; // converts the String selected to an integer index
					tendCrop(farm.getCropList().get(selectedIndex), farm.getPlantProductList().get(0)); // calls the tendCrop(Crop, PlantProduct) function with the crop at the selected index in cropList and the first plant product in plantProductList
					viewStatus(farm.getCropList().get(selectedIndex)); // ensures the status is updated
					itemPanel.setVisible(false); // makes the plant product items invisible again
					itemStatsPanel.setVisible(false);
				}
				break;
			// what happens if you press the second plant product button
			case "item2":
				if(selected != null) {
					int selectedIndex = Integer.parseInt(selected) - 1;
					tendCrop(farm.getCropList().get(selectedIndex), farm.getPlantProductList().get(1));
					viewStatus(farm.getCropList().get(selectedIndex));
					itemPanel.setVisible(false);
					itemStatsPanel.setVisible(false);
				}
				break;
			// what happens if you press the third plant product button
			case "item3":
				if(selected != null) {
					int selectedIndex = Integer.parseInt(selected) - 1;
					tendCrop(farm.getCropList().get(selectedIndex), farm.getPlantProductList().get(2));
					viewStatus(farm.getCropList().get(selectedIndex));
					itemPanel.setVisible(false);
					itemStatsPanel.setVisible(false);
				}
				break;
			// what happens if you press the fourth plant product button
			case "item4":
				if(selected != null) {
					int selectedIndex = Integer.parseInt(selected) - 1;
					tendCrop(farm.getCropList().get(selectedIndex), farm.getPlantProductList().get(3));
					viewStatus(farm.getCropList().get(selectedIndex));
					itemPanel.setVisible(false);
					itemStatsPanel.setVisible(false);
				}
				break;
			// what happens if you press the water button
			case "water":
				if(selected != null) {
					int selectedIndex = Integer.parseInt(selected) - 1;
					tendCrop(farm.getCropList().get(selectedIndex)); // calls the tendCrop(Crop) function with the crop at the selected index in cropList
					viewStatus(farm.getCropList().get(selectedIndex));
					itemPanel.setVisible(false);
					itemStatsPanel.setVisible(false);
				}
				break;
			// what happens if you press the back button
			case "back":
				closeCropScreen(); // closes the crop screen
				createMainScreen(); // opens the main screen
				break;
			}
		}
	}
	
	/**
	 * Handles any actions taking place on the animal screen,
	 * such as selecting an animal from the list (of buttons),
	 * playing with a selected animal, feeding a selected animal,
	 * choosing which item you feed to the animal, and pressing
	 * the back button.
	 * @author Billie Johnson
	 */
	public class AnimalScreenHandler implements ActionListener{
		/**
		 * Implements a switch based on the action command
		 * output by the button that the user clicks.
		 * If the user clicks any of the buttons representing
		 * animals, the animal is selected and the animal's
		 * status is shown on screen.
		 * If the user clicks on the play with animal button,
		 * then the playWithAnimal() function is called with
		 * the selected animal.
		 * If the user clicks on the feed animal button, then 
		 * the feedAnimal() function is called with the 
		 * selected animal.
		 * If the user clicks on any of the buttons representing
		 * animal products, then the gainsHealth() function of 
		 * the animal is called with the animal product.
		 * If the user clicks on the back button, then the animal
		 * screen is closed and the main screen is opened.
		 * @param event
		 */
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
			// what happens if you press the first button in the list
			case "1":
				if(farm.getAnimalList().size() >= 1) { // checks to make sure there is an animal at the first index (zero-indexed)
					viewStatus(farm.getAnimalList().get(0)); // calls the viewStatus function with the first animal in animalList
					selected = "1"; // updates which choice is currently selected
				}
				break;
			case "2":
				if(farm.getAnimalList().size() >= 2) {
					viewStatus(farm.getAnimalList().get(1));
					selected = "2";
				}
				break;
			case "3":
				if(farm.getAnimalList().size() >= 3) {
					viewStatus(farm.getAnimalList().get(2));
					selected = "3";
				}
				break;
			case "4":
				if(farm.getAnimalList().size() >= 4) {
					viewStatus(farm.getAnimalList().get(3));
					selected = "4";
				}
				break;
			// what happens if you press the Play With Animal button
			case "play":
				switch(selected) {
				case "1": // if the selected animal is in slot 1
					playWithAnimal(farm.getAnimalList().get(0)); // call the playWithAnimal function with the first animal in animalList
					viewStatus(farm.getAnimalList().get(0)); // ensures the status is updated
					break;
				case "2":
					playWithAnimal(farm.getAnimalList().get(1));
					viewStatus(farm.getAnimalList().get(1));
					break;
				case "3":
					playWithAnimal(farm.getAnimalList().get(2));
					viewStatus(farm.getAnimalList().get(2));
					break;
				case "4":
					playWithAnimal(farm.getAnimalList().get(3));
					viewStatus(farm.getAnimalList().get(3));
					break;
				}
				break;
			// what happens if you press the Feed Animal button
			case "feed":
				switch(selected) {
				case "1": // if the selected animal is in slot 1
					feedAnimal(farm.getAnimalList().get(0)); // call the feedAnimal function with the first animal in animalList
					viewStatus(farm.getAnimalList().get(0)); // ensures the status is updated
					break;
				case "2":
					feedAnimal(farm.getAnimalList().get(1));
					viewStatus(farm.getAnimalList().get(1));
					break;
				case "3":
					feedAnimal(farm.getAnimalList().get(2));
					viewStatus(farm.getAnimalList().get(2));
					break;
				case "4":
					feedAnimal(farm.getAnimalList().get(3));
					viewStatus(farm.getAnimalList().get(3));
					break;
				}
				break;
				// what happens if you press the first animal product button
				case "item1":
					if(selected != null) { // checks to ensure the player has selected an animal
						int selectedIndex = Integer.parseInt(selected) - 1; // converts the String selected to an integer index
						farm.getAnimalList().get(selectedIndex).gainsHealth(farm.getAnimalProductList().get(0)); // calls the gainsHealth(AnimalProduct) function of the selected animal with the selected animal product
						farm.animalProductList.remove(0); // removes the used animal product from the farm's list
						viewStatus(farm.getAnimalList().get(selectedIndex)); // ensures the status is updated
						closeAnimalScreen(); // updates the animal products shown
						createAnimalScreen();
					}
					break;
				// what happens if you press the second animal product button
				case "item2":
					if(selected != null) {
						int selectedIndex = Integer.parseInt(selected) - 1;
						farm.getAnimalList().get(selectedIndex).gainsHealth(farm.getAnimalProductList().get(1));
						farm.animalProductList.remove(1);
						viewStatus(farm.getAnimalList().get(selectedIndex));
						closeAnimalScreen();
						createAnimalScreen();
					}
					break;
				// what happens if you press the third animal product button
				case "item3":
					if(selected != null) {
						int selectedIndex = Integer.parseInt(selected) - 1;
						farm.getAnimalList().get(selectedIndex).gainsHealth(farm.getAnimalProductList().get(2));
						farm.animalProductList.remove(2);
						viewStatus(farm.getAnimalList().get(selectedIndex));
						closeAnimalScreen();
						createAnimalScreen();
					}
					break;
				// what happens if you press the fourth animal product button
				case "item4":
					if(selected != null) {
						int selectedIndex = Integer.parseInt(selected) - 1;
						farm.getAnimalList().get(selectedIndex).gainsHealth(farm.getAnimalProductList().get(3));
						farm.animalProductList.remove(3);
						viewStatus(farm.getAnimalList().get(selectedIndex));
						closeAnimalScreen();
						createAnimalScreen();
					}
					break;
			// what happens if you press the back button
			case "back":
				closeAnimalScreen(); // close the animal screen
				createMainScreen(); // open the main screen
				break;
			}
		}
	}
	
	/**
	 * @author willmiller
	 * a class to handle the button presses in the store screen
	 * namely, the back button and the item buttons
	 */
	public class StoreScreenHandler implements ActionListener{
		
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
				case "back": 			//back button is pressed
				closeStoreScreen(); 	// close the store screen and 
				createMainScreen(); 	// go back to the main screen
				storeBasket.clear();
				break;
				
				case "barley":									//the barley button was pressed 
					productInfoArea.setText(barley.toString());		// set the text in productInfoArea to show the details of barley and 
					basketButton.setActionCommand("barley");		// set the basketButton so that if pressed, barley is added to the basket
					break;											// basketHandler (next class down) deals with the actual adding of the barley
					
				case "wheat":									// the rest of the code blocks in this class work in precisely the same way
					productInfoArea.setText(wheat.toString());
					basketButton.setActionCommand("wheat");
					break;
				
				case "carrot":
					productInfoArea.setText(carrot.toString());
					basketButton.setActionCommand("carrot");
					break;
				
				case "kumara":
					productInfoArea.setText(kumara.toString());
					basketButton.setActionCommand("kumara");
					break;
				
				case "parsnip":
					productInfoArea.setText(parsnip.toString());
					basketButton.setActionCommand("parsnip");
					break;
				
				case "potato":
					productInfoArea.setText(potato.toString());
					basketButton.setActionCommand("potato");
					break;
				
				case "cow":
					productInfoArea.setText(cow.toString());
					basketButton.setActionCommand("cow");
					break;
				
				case "pig":
					productInfoArea.setText(pig.toString());
					basketButton.setActionCommand("pig");
					break;
				
				case "sheep":
					productInfoArea.setText(sheep.toString());
					basketButton.setActionCommand("sheep");
					break;
				
				case "weedKiller":
					productInfoArea.setText(weedKiller.toString());
					basketButton.setActionCommand("weedKiller");
					break;
				
				case "nutrients":
					productInfoArea.setText(nutrients.toString());
					basketButton.setActionCommand("nutrients");
					break;
				
				case "fertilizer":
					productInfoArea.setText(fertilizer.toString());
					basketButton.setActionCommand("fertilizer");
					break;
				
				case "compost":
					productInfoArea.setText(compost.toString());
					basketButton.setActionCommand("compost");
					break;
				
				case "pellets":
					productInfoArea.setText(pellets.toString());
					basketButton.setActionCommand("pellets");
					break;
				
				case "medicine":
					productInfoArea.setText(medicine.toString());
					basketButton.setActionCommand("medicine");
					break;
			}
		}
	}
	
	
	/**
	 * @author willmiller
	 * a class to deal with buttons to do with the basket.
	 * namely, viewing the basket which takes you to the BasketScreen and 
	 * adding items to the basket
	 */
	public class BasketHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
			
			case "view basket":				// if the player wants to view the basket, 
				closeStoreScreen();			// this StoreScreen closes and 
				createBasketScreen();		// the BasketScreen is opened
				
			
			case "barley":					// this is the ActionCommand from StoreScreenHandler above
				storeBasket.add(barley);	// it adds barley to the player's basket
				break;
				
			case "wheat":				    // the rest of the code blocks in this class work in precisely the same way
				storeBasket.add(wheat);
				break;
				
			case "carrot":
				storeBasket.add(carrot);
				break;
				
			case "kumara":
				storeBasket.add(kumara);
				break;
				
			case "parsnip":
				storeBasket.add(parsnip);
				break;
				
			case "potato":
				storeBasket.add(potato);
				break;
				
			case "cow":
				storeBasket.add(cow);
				break;
				
			case "pig":
				storeBasket.add(pig);
				break;
				
			case "sheep":
				storeBasket.add(sheep);
				break;
				
			case "weedKiller":
				storeBasket.add(weedKiller);
				break;
				
			case "nutrients":
				storeBasket.add(nutrients);
				break;
				
			case "fertilizer":
				storeBasket.add(fertilizer);
				break;
				
			case "compost":
				storeBasket.add(compost);
				break;
				
			case "pellets":
				storeBasket.add(pellets);
				break;
				
			case "medicine":
				storeBasket.add(medicine);
				break;
			}
		}
	}
	
	/**
	 * @author willmiller
	 * a class to deal with button pushes on the BasketScreen
	 * Allows the player to go back to the store screen without buyin anything or 
	 * they can purchase their basket, at which point they are sent back to the store screen
	 */
	
	public class BasketScreenHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
			case "back" :    					// goes back to the StoreScreen without purchasing anything
				closeBasketScreen();
				createStoreScreen();
				break;
	
			case "purchase" :					// the player purchases their basket
				purchaseBasket(storeBasket);	
				storeBasket.clear();			// the basket is 'emptied' ie the ArrayList is cleared
				closeBasketScreen();			// the BasketScreeen is closed and 
				createStoreScreen();
				break;
			}
		}
	}

	
	/**
	 * Handles any actions taking place on the end screen,
	 * such as pressing the restart button or exit button.
	 * @author Billie Johnson
	 */
	public class EndScreenHandler implements ActionListener{
		/**
		 * Implements a switch based on the action command
		 * output by the button that the user clicks.
		 * If the user chooses to restart, the window is closed
		 * and a new game is started.
		 * If the user chooses to exit, the game is exited.
		 * @param event 
		 */
		public void actionPerformed(ActionEvent event) {
			String choice = event.getActionCommand(); // gets the string linked to the button you have pressed
			switch(choice) {
			// what happens if you press the restart button
			case "restart":
				closeEndScreen(); // resets everything from the end screen
				window.dispose(); // closes the window
				new GameEnvironment(); // creates new game
				break;
			// what happens if you press the exit button
			case "exit":
				System.exit(0); // closes game
				break;
			}
		}
	}
	
	
	/**
	 * Checks if an input number is valid.
	 * It should be valid if the number can be converted to an integer,
	 * i.e. only contains 0-9, and is not null or empty.
	 * @param input A String input by the user.
	 * 				It should be a number.
	 */
	public boolean checkIntInput(String input) {
		if(input.matches("[0-9]*") && input != "") {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if an input String is valid.
	 * It should be valid if the String has no special characters or numbers,
	 * and is not null or empty.
	 * @param input A String input by the user.
	 */
	public boolean checkStringInput(String input) {
		if(input.matches("[a-zA-Z]+[ ]*[a-zA-Z]*")) {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if an input duration is valid.
	 * It should be valid if the input integer is between 5 and 10.
	 * @param duration An integer input by the user.
	 */
	public boolean checkValidDuration(int duration) {
		if(duration <= 10 && duration >= 5) {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if an input name is valid.
	 * It should be valid if the name is between 3 and 15 characters.
	 * @param name A String input by the user.
	 */
	public boolean checkValidName(String name) {
		if(checkStringInput(name) == true) {
			if(name.length() < 3 || name.length() > 15) {
				return false;
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Displays the maintenance level of the farm.
	 * @param farm The Farm object, specifies that you are calling viewStatus(Farm)
	 */
	public void viewStatus(Farm farm) {
		maintenancePanel.setVisible(true);
	}
	
	/**
	 * Displays the status of the chosen crop in a text box.
	 * It includes the name, the time growing, 
	 * the time until it can be harvested, 
	 * and the money gained from harvesting it.
	 * @param crop The Crop object that the user wishes to view the status of.
	 */
	public void viewStatus(Crop crop) {
		itemStatus.setText(crop.name + "\nIt has been growing for " + crop.timeGrowing + " days\nIt can be harvested in " + crop.timeUntilHarvest + " days\nIt gives $" + crop.sellingPrice + " when harvested");
	}
	
	/**
	 * Displays the status of the chosen animal in a text box.
	 * It includes the name, health, happiness, and daily money gained from it.
	 * @param animal The Animal object that the user wishes to view the status of.
	 */
	public void viewStatus(Animal animal) {
		itemStatus.setText(animal.name + "\nIts health is " + animal.health + "\nIts happiness is " + animal.happiness + "\nIt gives $" + animal.dailyMoney(animal.happiness, animal.health) + " per day");
	}
	
	/**
	 * Checks if the player has any actions remaining, if they do,
	 * calls the watered() function of the crop, which reduces the
	 * time until the plant to be harvested.
	 * If they do not have any actions remaining, text appears on
	 * screen to inform the player that they have no actions
	 * remaining.
	 * @param crop The Crop that the player wants to tend to.
	 */
	public void tendCrop(Crop crop) {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			crop.watered(); // calls the watered() function of the crop, which reduces the time until the crop can be harvested
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the remaining actions label
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	/**
	 * Checks if the player has any actions remaining, if they do,
	 * calls the growingDaysReduced(PlantProduct) function of the
	 * crop, which reduces the time until the plant to be harvested
	 * by different amounts depending on which plant product is used.
	 * If they do not have any actions remaining, text appears on
	 * screen to inform the player that they have no actions
	 * remaining.
	 * @param crop The Crop that the player wants to tend to.
	 * @param plantProduct The PlantProduct that the player wants to
	 * 					   use on the crop.
	 */
	public void tendCrop(Crop crop, PlantProduct plantProduct) {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			crop.growingDaysReduced(plantProduct); // calls the growingDaysReduced() function of the crop, which reduces the time until the crop can be harvested
			farm.plantProductList.remove(plantProduct); // removes the used plant product from the farm's list
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the remaining actions label
			closeCropScreen(); // updates the crop screen with the current plant products available
			createCropScreen();
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	/**
	 * Checks if the player has any actions remaining, if they do,
	 * harvests each crop that the farm has which have zero or less days
	 * until they can be harvested. Harvesting the crop returns the money
	 * it provides upon being harvested, and adds this to the farm's balance.
	 * If they do not have any actions remaining, text appears on
	 * screen to inform the player that they have no actions
	 * remaining.
	 */
	public void harvestCrops() {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			for(Crop crop: farm.cropList) { // for each crop that the farm has
				if(crop.timeUntilHarvest <= 0) { // if the time until the crop can be harvested is zero or less
					int moneyEarned = crop.harvest(); // calls the harvest() function of the crop, which returns the money provided by harvesting the crop
					farm.addBalance(moneyEarned); // adds the money provided by harvesting the crop to the farm's balance
					farm.cropList.remove(crop); // removes a crop from the farm's cropList when it's harvested
				}
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
			balanceLabel.setText("Balance: $" + farm.getBalance()); // updates the balance label
			closeCropScreen(); // updates the crop screen with the current crops
			createCropScreen();
			}
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	/**
	 * Checks if the player has any actions remaining, if they do,
	 * calls the getsFed() function of the animal, which
	 * increases the animal's health and happiness, removes an action, 
	 * and updates the relevant labels.
	 * If they do not have any actions remaining, text appears on
	 * screen to inform the player that they have no actions
	 * remaining.
	 * @param animal The Animal that the user has selected
	 */
	public void feedAnimal(Animal animal) {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			animal.getsFed(); // calls the getsFed() function of the animal
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	/**
	 * Checks if the player has any actions remaining, if they do,
	 * calls the getsPlayedWith() function of the animal, which
	 * increases the animal's happiness, removes an action, and updates
	 * the relevant labels.
	 * If they do not have any actions remaining, text appears on
	 * screen to inform the player that they have no actions
	 * remaining.
	 * @param animal The Animal that the user has selected
	 */
	public void playWithAnimal(Animal animal) {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			animal.getsPlayedWith(); // calls the getsPlayedWith() function of the animal
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	/**
	 * Checks if the player has any actions remaining,
	 * if they do, increases the maintenance level,
	 * removes an action, and updates the relevant labels.
	 * If they do not have any actions remaining,
	 * text appears on screen to inform them they
	 * have no actions remaining.
	 */
	public void tendLand() {
		if(farmer.actionsLeft > 0) { // checks that the farmer has actions remaining
			farm.increaseMaintenance(); // increases the maintenance level of the farm
			maintenanceLabel.setText("Maintenance level is at " + farm.getMaintenance() + "%"); // updates the maintenance label
			farmer.removeAction(); // decreases the actions remaining by 1
			actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
		}
		else {
			noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		}
	}
	
	
	/**
	 * adds the items to their respective lists on the farm, and 
	 * deducts the cost of the items from the farms balance
	 * @param basket an ArrayList of items from the store that the player has 'added to their basket'
	 */
	public void purchaseBasket(ArrayList<Item> storeBasket) {
		
		if (farmer.actionsLeft > 0) { 								// check the farmer has an action remaining to perform the purchase
			
			farmer.removeAction();									// purchasing costs 1 action	

			double totalBasketCost = 0;
			for (Item item: storeBasket) {							// works out the total cost of the basket
				totalBasketCost += item.getPurchasePrice();			
			}
			
			if (totalBasketCost < farm.getBalance()) {				// checks the farmer has enough money for the purchase
			
				for (Item item: storeBasket) {							// iterate over all items in the basket
					if (item instanceof Animal) {						// first we deal with Animal items
						Animal animal = (Animal)item;					// turn it from an Item into an Animal
																		// note this is guaranteed to work as we checked that it was an instanceof Animal
						farm.addToAnimalList(animal);					// add it to the farm's AnimalList
						farm.removeBalance(animal.getPurchasePrice());	// and finally take the cost off the farm's balance
						}	
						
					if (item instanceof Crop) {							// now do the same for crop items 
						Crop crop = (Crop)item;
						farm.addToCropList(crop);
						farm.removeBalance(crop.getPurchasePrice());
						
						}
					if (item instanceof AnimalProduct) {				// and AnimalProduct items 
						AnimalProduct animalProduct = (AnimalProduct)item;
						farm.addToAnimalProductList(animalProduct);
						farm.removeBalance(animalProduct.getPurchasePrice());
						}
					
					if (item instanceof PlantProduct) {					// and finally PlantProduct items
						PlantProduct plantProduct = (PlantProduct)item;
						farm.addToPlantProductList(plantProduct);
						farm.removeBalance(plantProduct.getPurchasePrice());
						}
					}
				actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
				balanceLabel.setText("Balance: $" + farm.getBalance()); // updates the balance label
			}
			else {
			}
			// notEnoughBalancePanel.setVisible(true);  // tells the user they don't have enough money
			// not implimented
		}
		else {
		// 	noActionsPanel.setVisible(true); // tells the user that they have no actions remaining
		// not implimented
		}
		
		}
	
	

	
	/**
	 * Sets the duration and initial daysRemaining value of the game.
	 * @param amount An integer that the player inputs.
	 */
	public void setDuration(int amount) {
		duration = amount;
		daysRemaining = amount;
	}
	
	/**
	 * Calculates the final score, by dividing the final balance by the duration of the game.
	 * @param farm This is the Farm object.
	 */
	public void calculateScore(Farm farm) {
		score = farm.getBalance() / duration;
	}
	
	/**
	 * Goes to the next day.
	 * Decreases maintenance, calls dayPasses() function of Crop, 
	 * adds the daily money given by each animal to the current balance, 
	 * resets the number of actions a farmer has, decreases daysRemaining by 1, 
	 * and updates relevant labels and panel visibility.
	 */
	public void nextDay() {
		farm.decreaseMaintenance(); // decreases the maintenance level of the farm
		maintenanceLabel.setText("Maintenance level is at " + farm.getMaintenance() + "%"); // updates the maintenance label
		for(Crop crop: farm.getCropList()) {
			crop.dayPasses(farm.cropGrowthMultiplier); // calls dayPasses() for each crop that the farm has
		}
		for(Animal animal: farm.getAnimalList()) {
			farm.addBalance(animal.dailyMoney(animal.happiness, animal.health)); // adds the daily money from each animal the farm has to the farm's balance
		}
		farmer.resetActions(); // resets the number of actions the farmer has
		actionsLabel.setText("Actions remaining: " + farmer.actionsLeft); // updates the actions remaining label
		maintenancePanel.setVisible(false); // hides the maintenance level panel
		noActionsPanel.setVisible(false); // hides the no actions remaining panel
		daysRemaining -= 1; // removes a day from days remaining
		daysLabel.setText("Days remaining: " + daysRemaining); // updates the days remaining label
		balanceLabel.setText("Balance: $" + farm.getBalance()); // updates the balance label
		if(daysRemaining == -1) { // checks if the daysRemaining is now less than 0
			calculateScore(farm); // calculates the final score
			createEndScreen(); // creates the end screen
		}
	}
	
	/**
	 * Sets the list of items that the store has.
	 * Adds all the crops, animals, plant products, and
	 * animal products that the player can purchase.
	 * @param list The ArrayList to add the items to
	 */
	public void setStoreItemList(ArrayList<Item> list) {
		// creates all the Crop items
		Barley barley = new Barley();
		Carrot carrot = new Carrot();
		Kumara kumara = new Kumara();
		Parsnip parsnip = new Parsnip();
		Potato potato = new Potato();
		Wheat wheat = new Wheat();
		// adds all the crop items to the store item list
		list.add(barley);
		list.add(carrot);
		list.add(kumara);
		list.add(parsnip);
		list.add(potato);
		list.add(wheat);
		
		// creates all the Animal items
		Cow cow = new Cow();
		Pig pig = new Pig();
		Sheep sheep = new Sheep();
		// adds all the animal items to the store item list
		list.add(cow);
		list.add(sheep);
		list.add(pig);
		
		// creates all the PlantProduct items
		Compost compost = new Compost();
		Fertilizer fertilizer = new Fertilizer();
		Nutrients nutrients = new Nutrients();
		WeedKiller weedKiller = new WeedKiller();
		// adds all the plant product items to the store item list
		list.add(compost);
		list.add(fertilizer);
		list.add(nutrients);
		list.add(weedKiller);
		
		// creates all the AnimalProduct items
		Medicine medicine = new Medicine(); 
		Pellets pellets = new Pellets();
		// adds all the animal product items to the store item list
		list.add(medicine);
		list.add(pellets);
	}
	
}
