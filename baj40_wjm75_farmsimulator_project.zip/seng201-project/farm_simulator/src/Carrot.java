/**
 * @author willmiller
 * a trusty carrot
 * a subclass of crop
 */

public class Carrot extends Crop {

	
	/**
	 * constructs the carrot with specific values
	 */
	public Carrot() {
		name = "Carrot";
		timeUntilHarvest = 2;
		sellingPrice = 10;
		purchasePrice = 3;
	}
	
	/**
	 * allows the carrot to be built in the GameEnvironment 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Carrot(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
