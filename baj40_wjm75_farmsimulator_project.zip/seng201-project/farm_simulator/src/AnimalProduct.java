/**
 * @author willmiller
 * a product that helps animals stay healthy 
 * subclass of item
 */

public class AnimalProduct extends Item{

	/**
	 * how much extra health is given to the animal that recieves this product
	 */
	public double healthGiven;
	
	/** 
	 * constructs the product with values to be added in the construction function
	 * this is how the subclasses will be constructed
	 */
	public AnimalProduct() {
	}
	
	
	/**
	 * allows the AnimalProduct to be created with specific values
	 * @param tempHealthGiven an input to be turned into healthGiven
	 * @param tempName an inut to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public AnimalProduct(double tempHealthGiven, String tempName, int tempPurchasePrice) {
		healthGiven = tempHealthGiven;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
	/**
	 *  @return a string representation of the product
	 */
	public String toString() {
		String result = this.name + " costs $" + this.purchasePrice + " and \ngives " + this.healthGiven + " health."; 
		return result;
	}
}
