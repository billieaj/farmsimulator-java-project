/**
 * @author willmiller
 * some medicine to really boost the health of the animals
 * subclass of AnimalProduct
 */

public class Medicine extends AnimalProduct{

	
	/**
	 * constructs the medicine with specific values 
	 */
	public Medicine() { 
		name = "Medicine";
		healthGiven = 80;
		purchasePrice = 30;
	}
	
}
