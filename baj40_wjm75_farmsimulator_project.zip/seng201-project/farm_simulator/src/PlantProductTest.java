import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlantProductTest {
	
	private static PlantProduct prod;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		prod = new PlantProduct(5, "Mulch", 20);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testPlantProduct() {
		assertEquals(5, prod.growingDaysReduced);
		assertEquals("Mulch", prod.name);
		assertEquals(20, prod.purchasePrice);
	}

	@Test
	void testToString() {
		String prodString = prod.toString();
		String expectedString = "Mulch costs $20\n and reduces growing \ntime by 5 days.";
		assertEquals(expectedString, prodString);
	}
}
