/**
 * @author willmiller
 * weeds aren't good for plants, killing them helps plants grow
 * a subclass of PlantProduct
 */

public class WeedKiller extends PlantProduct{
	
	/**
	 * constructs the weed killer with specific values
	 */
	public WeedKiller() {
		name = "Weed Killer";
		purchasePrice = 4;
		growingDaysReduced = 1;
	}

	/**
	 *  WeedKiller needs a special case toString as growingDaysReduced is only 1 day
	 *  The PlantProduct toString() function uses days (plural)
	 */
	public String toString() {
		String result = this.name + " costs $" + this.purchasePrice + "\n and reduces growing \ntime by " + this.growingDaysReduced +  " day.";
		return result;
		
	}
}
