import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ItemTest {
	
	private static Item item;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		item = new Item("Rice", 20);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testItem() {
		assertEquals("Rice", item.name);
		assertEquals(20, item.purchasePrice);
	}
	
	@Test
	void testGetName() {
		String itemName = item.getName();
		String expectedName = "Rice";
		assertEquals(expectedName, itemName);
	}
	
	@Test
	void testGetPurchasePrice() {
		int itemPrice = item.getPurchasePrice();
		int expectedPrice = 20;
		assertEquals(expectedPrice, itemPrice);
	}

}
