import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AnimalTest {
	
	private static Animal cow;
	private static AnimalProduct pellets;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		cow = new Animal(10, 20, "Cow", 15);
		pellets = new AnimalProduct(10, "Pellets", 5);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		cow.happiness = 10;
		cow.health = 20;
	}

	@Test
	void testAnimal() {
		assertEquals(10, cow.happiness);
		assertEquals(20, cow.health);
		assertEquals("Cow", cow.name);
		assertEquals("Cow", cow.getName());
		assertEquals(15, cow.purchasePrice);
		assertEquals(15, cow.getPurchasePrice());
	}
	
	@Test
	void testToString() {
		String cowString = cow.toString();
		String expectedString = "Cow costs: $15\nwith health: 20.0\nand happiness: 10.0";
		assertEquals(expectedString, cowString);
	}
	
	@Test
	void testDailyMoney() {
		double cowMoney = cow.dailyMoney(cow.happiness, cow.health);
		double expectedMoney = 2 * 10 + 3 * 20;
		assertEquals(expectedMoney, cowMoney);
	}
	
	@Test
	void testGainsHealth() {
		cow.gainsHealth(pellets);
		assertEquals(30, cow.health);
	}
	
	@Test
	void testGetsFed() {
		cow.getsFed();
		assertEquals(11, cow.happiness);
		assertEquals(22, cow.health);
	}
	
	@Test
	void testGetsPlayedWith() {
		cow.getsPlayedWith();
		assertEquals(13, cow.happiness);
	}

}
