/**
 * An item in the game
 * Acts as a superclass for the different types of items that can be bought in the store
 * @Author Will Miller
 */

public class Item {
	
	
	/**
	 * the name of the item
	 */
	public String name;
	
	/**
	 * the cost of the item
	 */
	public int purchasePrice;
	
	/**
	 * Constructs the item with values to be added in the construction function
	 */
	public Item() {
	}
	
	/**
	 * Constructs the item with specified values
	 */
	public Item(String tempName, int tempPurchasePrice) {
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
	/**
	 * @return name of the item
	 */
	public String getName() {
		String result = name;
		return result;
	}
	
	/**
	 * 
	 * @return the cost of the item
	 */
	public int getPurchasePrice() {
		int result = purchasePrice;
		return result;
	}
}