/**
 * @author willmiller
 * plant Products to help plants grow faster
 * subclass of Item
 */

public class PlantProduct extends Item{
	
	
	/**
	 * how many days the recieving plant's growth is reduced by 
	 */
	public int growingDaysReduced;

	
	/**
	 * constructs the plantProduct with values to be added in the construction function
	 * this is how the subclasses will be constructed
	 */
	public PlantProduct() {
	}
	
	/**
	 * allows the plantProduct to be constructed with specific values 
	 * @param tempGrowingDaysReduced an input to be turned into growingDaysReduced
	 * @param tempName an input to be turned into name 
	 * @param tempPurchasePrice an input to be turned into purchasePrice 
	 */
	public PlantProduct(int tempGrowingDaysReduced, String tempName, int tempPurchasePrice) {
		growingDaysReduced = tempGrowingDaysReduced;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
	
	/**
	 * @return a string representation of the plantProduct
	 */
	public String toString() {
		String result = this.name + " costs $" + this.purchasePrice + "\n and reduces growing \ntime by " + this.growingDaysReduced +  " days.";
		return result;
	}
	
}
