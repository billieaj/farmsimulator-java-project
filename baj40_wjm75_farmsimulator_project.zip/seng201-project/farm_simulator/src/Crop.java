/**
 * @author willmiller
 * A crop to be planted on the farm
 * Subclass of item
 */

public class Crop extends Item{
	
	
	/**
	 * the time the crop has been growing.
	 * Initialised to zero
	 */
	public int timeGrowing = 0;
	
	/**
	 * the time until the crop is ready for harvest 
	 */
	public int timeUntilHarvest;
	
	/** 
	 * How much the crop can be sold for when it's harvested
	 */
	public int sellingPrice;
	
	
	/** 
	 * constructs the crop with values to be added in the construction function
	 * this is how the subclasses will be constructed
	 */
	public Crop() {
	}
	
	
	/**
	 * allows the crop to be constructed with specific values 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Crop(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
	
	
	/**
	 * @param product is a plant product that can be given to the crop
	 * the product will then cause the crop to be ready for harvest earlier than it otherwise would have been
	 */
	public void growingDaysReduced(PlantProduct product) {
		int daysReduced = product.growingDaysReduced;
		timeUntilHarvest -= daysReduced;

	}
	
	/**
	 * @return a string representation of the crop for the store
	 */
	public String toString() { 
		String result = this.name + " costs $" + this.purchasePrice + ", has " + this.timeUntilHarvest + "\ndays until fully grown, \nand sells for $" + this.sellingPrice;
		return result;
	}
	
	/**
	 *  when another day passes in the game, it has been growing for one more day
	 *  and is one day closer to being ready for harvest
	 */
	public void dayPasses(double cropGrowthMultiplier) {
		timeGrowing += 1;
		timeUntilHarvest -= 1 * cropGrowthMultiplier;
	}
	
	
	/**
	 * a player can use their action to water the crop, which makes it ready for harvest sooner
	 */
	public void watered() {
		timeUntilHarvest -= 1;
	}
	
	/**
	 * the player can harvest the crop when it's ready
	 * @return money to be added to the farm's balance
	 */
	public int harvest() {
		if (timeUntilHarvest <= 0) {
			int moneyEarned = sellingPrice;
			return moneyEarned;
		}
		else {
			return 0;
		}
	}
}
