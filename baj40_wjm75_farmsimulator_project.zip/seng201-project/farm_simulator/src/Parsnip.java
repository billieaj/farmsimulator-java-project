/**
 * @author willmiller
 * a parsnip, goes nicely in soup
 * a subclass of crop
 */

public class Parsnip extends Crop {

	
	/**
	 * constructs the parsnip with specific values 
	 */
	public Parsnip() {
		name = "Parsnip";
		timeUntilHarvest = 9;
		sellingPrice = 40;
		purchasePrice = 12;
	}
	
	/**
	 * allows the parsnip to be built in the GameEnvironment 
	 * @param tempTimeGrowing an input to be turned into timeGrowing
	 * @param tempTimeUntilHarvest an input to be turned into timeUntilHarvest 
	 * @param tempSellingPrice an input to be turned into sellingPrice
	 * @param tempName an input to be turned into name
	 * @param tempPurchasePrice an input to be turned into purchasePrice
	 */
	public Parsnip(int tempTimeGrowing, int tempTimeUntilHarvest, int tempSellingPrice, String tempName, int tempPurchasePrice) {
		timeGrowing = tempTimeGrowing;
		timeUntilHarvest = tempTimeUntilHarvest;
		sellingPrice = tempSellingPrice;
		name = tempName;
		purchasePrice = tempPurchasePrice;
	}
}
