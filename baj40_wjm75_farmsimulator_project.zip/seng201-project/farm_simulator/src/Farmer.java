/**
 * Represents a farmer in the game.
 * @author Billie Johnson
 */
public class Farmer {
	
	/**
	 * The name of this farmer.
	 */
	public String name;
	// Integers
	/**
	 * The age of this farmer.
	 */
	public int age;
	/**
	 * The number of actions the player has remaining.
	 * Default is 10.
	 */
	public int actionsLeft;
	
	/**
	 * Creates a new Farmer with default values.
	 */
	public Farmer() {
		name = "Farmer";
		age = 20;
		actionsLeft = 10;
	}
	
	/**
	 * Changes the name of this farmer.
	 * @param newName The new name of this Farmer.
	 */
	public void setName(String newName) {
		name = newName;
	}
	
	/**
	 * Changes the age of this farmer.
	 * @param newAge The new age of this Farmer.
	 */
	public void setAge(int newAge) {
		age = newAge;
	}
	
	/**
	 * Decreases the number of actions remaining by 1.
	 */
	public void removeAction() {
		actionsLeft -= 1;
	}
	
	/**
	 * Resets the number of actions the player has
	 * left back to 10.
	 */
	public void resetActions() {
		actionsLeft = 10;
	}
}
